import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  AlertTriangle,
  Bot,
  CheckCircle2,
  ChevronRight,
  ExternalLink,
  Info,
  Loader2,
  RefreshCw,
  Unplug,
  Wifi,
  WifiOff,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Dashboard() {
  return (
    <DashboardLayout>
      <DashboardContent />
    </DashboardLayout>
  );
}

function DashboardContent() {
  const [, setLocation] = useLocation();

  // ── QBO connection state ────────────────────────────────────────────────────
  const { data: credStatus } = trpc.qbo.credentialsReady.useQuery();
  const { data: qboStatus, isLoading: qboLoading, refetch: refetchQbo } =
    trpc.qbo.status.useQuery();

  // ── Findings summary ────────────────────────────────────────────────────────
  const { data: allFindings } = trpc.findings.list.useQuery({});

  // ── Healthcheck runs ────────────────────────────────────────────────────────
  const { data: runs } = trpc.diagnostics.listRuns.useQuery({});

  // ── Connect mutation ────────────────────────────────────────────────────────
  const connectMutation = trpc.qbo.getConnectUrl.useMutation({
    onSuccess: ({ url }) => {
      window.location.href = url;
    },
    onError: (err) => {
      toast.error(err.message);
    },
  });

  // ── Disconnect mutation ─────────────────────────────────────────────────────
  const disconnectMutation = trpc.qbo.disconnect.useMutation({
    onSuccess: () => {
      toast.success("QuickBooks disconnected.");
      refetchQbo();
    },
    onError: (err) => {
      toast.error(err.message);
    },
  });

  // ── Handle OAuth callback query params ─────────────────────────────────────
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("qbo_connected") === "1") {
      toast.success("QuickBooks connected successfully!");
      refetchQbo();
      // Clean up URL
      window.history.replaceState({}, "", "/dashboard");
    }
    if (params.get("qbo_error")) {
      toast.error(`QuickBooks error: ${params.get("qbo_error")}`);
      window.history.replaceState({}, "", "/dashboard");
    }
  }, [refetchQbo]);

  // ── Derived counts ──────────────────────────────────────────────────────────
  const criticalCount = allFindings?.filter((f) => f.severity === "critical" && f.status === "open").length ?? 0;
  const warningCount = allFindings?.filter((f) => f.severity === "warning" && f.status === "open").length ?? 0;
  const infoCount = allFindings?.filter((f) => f.severity === "info" && f.status === "open").length ?? 0;
  const lastRun = runs?.[0];

  const isConnected = qboStatus?.connected ?? false;
  const credentialsConfigured = credStatus?.configured ?? false;

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Page header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">
          QuickBooks diagnostic overview and connection status.
        </p>
      </div>

      {/* ── QuickBooks Connection Card ─────────────────────────────────────── */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CardTitle className="text-base">QuickBooks Connection</CardTitle>
              {qboLoading ? (
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              ) : isConnected ? (
                <Badge className="bg-green-500/15 text-green-400 border border-green-500/30 text-xs">
                  <Wifi className="h-3 w-3 mr-1" /> Connected
                </Badge>
              ) : (
                <Badge className="bg-muted text-muted-foreground border border-border text-xs">
                  <WifiOff className="h-3 w-3 mr-1" /> Not connected
                </Badge>
              )}
            </div>
          </div>
          <CardDescription>
            {isConnected
              ? `Connected to ${qboStatus?.connection?.companyName ?? "your QuickBooks company"}`
              : "Connect your QuickBooks Online account to begin diagnostics."}
          </CardDescription>
        </CardHeader>

        <CardContent>
          {/* ── Not connected states ─────────────────────────────────────── */}
          {!isConnected && !qboLoading && (
            <div className="space-y-4">
              {/* Credentials not configured */}
              {!credentialsConfigured && (
                <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-4 flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-amber-300">
                      QuickBooks credentials not configured
                    </p>
                    <p className="text-xs text-amber-400/80 leading-relaxed">
                      Add <code className="font-mono bg-amber-500/20 px-1 rounded">QBO_CLIENT_ID</code>,{" "}
                      <code className="font-mono bg-amber-500/20 px-1 rounded">QBO_CLIENT_SECRET</code>, and{" "}
                      <code className="font-mono bg-amber-500/20 px-1 rounded">QBO_REDIRECT_URI</code> to your{" "}
                      <code className="font-mono bg-amber-500/20 px-1 rounded">.env</code> file, then restart the server.
                      See the README for the exact redirect URI to register in Intuit.
                    </p>
                  </div>
                </div>
              )}

              {/* Credentials configured but not connected */}
              {credentialsConfigured && (
                <div className="rounded-lg border border-border bg-secondary/40 p-4 flex gap-3">
                  <Info className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Click <strong className="text-foreground">Connect QuickBooks</strong> to authorise LedgerRx
                    to read your accounting data. You will be redirected to Intuit to complete the OAuth flow.
                  </p>
                </div>
              )}

              <Button
                onClick={() => connectMutation.mutate()}
                disabled={connectMutation.isPending || !credentialsConfigured}
                className="gap-2"
              >
                {connectMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ExternalLink className="h-4 w-4" />
                )}
                Connect QuickBooks
              </Button>
            </div>
          )}

          {/* ── Connected state ───────────────────────────────────────────── */}
          {isConnected && qboStatus?.connection && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
                <div className="rounded-lg bg-secondary/50 p-3 space-y-1">
                  <p className="text-xs text-muted-foreground">Company</p>
                  <p className="font-medium truncate">
                    {qboStatus.connection.companyName ?? "—"}
                  </p>
                </div>
                <div className="rounded-lg bg-secondary/50 p-3 space-y-1">
                  <p className="text-xs text-muted-foreground">Realm ID</p>
                  <p className="font-mono text-xs truncate">
                    {qboStatus.connection.realmId}
                  </p>
                </div>
                <div className="rounded-lg bg-secondary/50 p-3 space-y-1">
                  <p className="text-xs text-muted-foreground">Connected</p>
                  <p className="font-medium">
                    {new Date(qboStatus.connection.connectedAt).toLocaleDateString()}
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setLocation("/healthcheck")}
                  className="gap-2"
                >
                  <Activity className="h-4 w-4" />
                  Run Healthcheck
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => disconnectMutation.mutate()}
                  disabled={disconnectMutation.isPending}
                  className="gap-2 text-muted-foreground hover:text-destructive"
                >
                  {disconnectMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Unplug className="h-4 w-4" />
                  )}
                  Disconnect
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Stats row ────────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          {
            label: "Critical Findings",
            value: criticalCount,
            icon: AlertTriangle,
            color: "text-destructive",
            bg: "bg-destructive/10",
          },
          {
            label: "Warnings",
            value: warningCount,
            icon: AlertTriangle,
            color: "text-amber-400",
            bg: "bg-amber-500/10",
          },
          {
            label: "Info",
            value: infoCount,
            icon: Info,
            color: "text-blue-400",
            bg: "bg-blue-500/10",
          },
          {
            label: "Runs",
            value: runs?.length ?? 0,
            icon: RefreshCw,
            color: "text-primary",
            bg: "bg-primary/10",
          },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <Card key={label} className="border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`h-9 w-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                <Icon className={`h-4 w-4 ${color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* ── Quick actions ─────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          {
            icon: Activity,
            title: "Run Healthcheck",
            desc: "Scan your QuickBooks data for issues.",
            path: "/healthcheck",
            disabled: !isConnected,
          },
          {
            icon: CheckCircle2,
            title: "View Findings",
            desc: "Review and resolve open findings.",
            path: "/findings",
            disabled: false,
          },
          {
            icon: Bot,
            title: "Cleanup Copilot",
            desc: "AI-powered suggestions for your findings.",
            path: "/copilot",
            disabled: false,
          },
        ].map(({ icon: Icon, title, desc, path, disabled }) => (
          <button
            key={title}
            onClick={() => !disabled && setLocation(path)}
            disabled={disabled}
            className={`text-left rounded-xl border border-border bg-card p-5 space-y-2 transition-colors
              ${disabled
                ? "opacity-50 cursor-not-allowed"
                : "hover:border-primary/50 hover:bg-accent/30 cursor-pointer"
              }`}
          >
            <div className="flex items-center justify-between">
              <div className="h-9 w-9 rounded-lg bg-primary/15 flex items-center justify-center">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-sm">{title}</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
            {disabled && (
              <p className="text-xs text-amber-400">Requires QuickBooks connection</p>
            )}
          </button>
        ))}
      </div>

      {/* ── Last run summary ──────────────────────────────────────────────────── */}
      {lastRun && (
        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Last Healthcheck Run
            </CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Badge
                className={
                  lastRun.status === "completed"
                    ? "bg-green-500/15 text-green-400 border-green-500/30"
                    : lastRun.status === "failed"
                    ? "bg-destructive/15 text-destructive border-destructive/30"
                    : "bg-muted text-muted-foreground border-border"
                }
              >
                {lastRun.status}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {new Date(lastRun.startedAt).toLocaleString()}
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/healthcheck")}
              className="gap-1 text-xs"
            >
              Details <ChevronRight className="h-3 w-3" />
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
