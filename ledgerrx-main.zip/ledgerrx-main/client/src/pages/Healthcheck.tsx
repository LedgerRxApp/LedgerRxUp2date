import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  AlertCircle,
  CheckCircle2,
  Clock,
  Loader2,
  Play,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";

export default function Healthcheck() {
  return (
    <DashboardLayout>
      <HealthcheckContent />
    </DashboardLayout>
  );
}

const CHECK_CATALOG = [
  {
    key: "uncategorized_transactions",
    title: "Uncategorised Transactions",
    desc: "Transactions missing an account or category assignment.",
    severity: "critical",
  },
  {
    key: "duplicate_vendors",
    title: "Duplicate Vendors",
    desc: "Vendor names that appear to be duplicates or near-duplicates.",
    severity: "warning",
  },
  {
    key: "missing_customer_info",
    title: "Missing Customer Info",
    desc: "Customers with incomplete contact data (email, phone, address).",
    severity: "warning",
  },
  {
    key: "unreconciled_accounts",
    title: "Unreconciled Accounts",
    desc: "Bank accounts not reconciled in the past 30 days.",
    severity: "critical",
  },
  {
    key: "negative_inventory",
    title: "Negative Inventory",
    desc: "Inventory items with a negative quantity on hand.",
    severity: "warning",
  },
  {
    key: "stale_open_invoices",
    title: "Stale Open Invoices",
    desc: "Invoices that have been open for more than 90 days.",
    severity: "info",
  },
  {
    key: "mismatched_payments",
    title: "Mismatched Payments",
    desc: "Payments not matched to any invoice or bill.",
    severity: "warning",
  },
];

const SEVERITY_STYLES: Record<string, string> = {
  critical: "bg-destructive/10 text-destructive border-destructive/30",
  warning: "bg-amber-500/10 text-amber-400 border-amber-500/30",
  info: "bg-blue-500/10 text-blue-400 border-blue-500/30",
};

function HealthcheckContent() {
  const { data: qboStatus } = trpc.qbo.status.useQuery();
  const { data: runs, refetch: refetchRuns } = trpc.diagnostics.listRuns.useQuery({});

  const runHealthcheckMutation = trpc.diagnostics.runHealthcheck.useMutation({
    onSuccess: (data: any) => {
      toast.success(`Healthcheck completed in ${(data.durationMs / 1000).toFixed(1)}s. Found ${data.findingsSummary.total} findings.`);
      refetchRuns();
    },
    onError: (err: any) => {
      toast.error(err.message);
    },
  });

  const isConnected = qboStatus?.connected ?? false;
  const latestRun = runs?.[0];

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Page header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Healthcheck</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Run a full diagnostic scan across your QuickBooks data.
          </p>
        </div>
        <Button
          onClick={() => runHealthcheckMutation.mutate({})}
          disabled={!isConnected || runHealthcheckMutation.isPending}
          className="gap-2"
        >
          {runHealthcheckMutation.isPending ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Play className="h-4 w-4" />
          )}
          Run Healthcheck
        </Button>
      </div>

      {/* Not connected warning */}
      {!isConnected && (
        <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-4 flex gap-3">
          <AlertCircle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
          <p className="text-sm text-amber-300">
            Connect QuickBooks from the Dashboard before running a healthcheck.
          </p>
        </div>
      )}

      {/* Phase 2 notice */}
      <div className="rounded-lg border border-primary/20 bg-primary/5 p-4 flex gap-3">
        <Activity className="h-5 w-5 text-primary shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="text-sm font-medium text-primary">Phase 1 Scaffold</p>
          <p className="text-xs text-muted-foreground leading-relaxed">
            The healthcheck UI is scaffolded. Clicking "Run Healthcheck" creates a run record
            in the database (status: pending). The execution engine — which calls the QuickBooks
            API and evaluates each check — will be implemented in Phase 2 after credentials are added.
          </p>
        </div>
      </div>

      {/* Checks catalog */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-base">Diagnostic Checks</CardTitle>
          <CardDescription>
            {CHECK_CATALOG.length} checks will run when the execution engine is wired in Phase 2.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {CHECK_CATALOG.map((check) => (
            <div
              key={check.key}
              className="flex items-center justify-between rounded-lg border border-border bg-secondary/30 px-4 py-3"
            >
              <div className="flex items-center gap-3 min-w-0">
                <CheckCircle2 className="h-4 w-4 text-muted-foreground shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{check.title}</p>
                  <p className="text-xs text-muted-foreground truncate">{check.desc}</p>
                </div>
              </div>
              <Badge className={`ml-3 shrink-0 text-xs border ${SEVERITY_STYLES[check.severity]}`}>
                {check.severity}
              </Badge>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Run history */}
      <Card className="border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Run History</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => refetchRuns()}
              className="gap-1 text-xs"
            >
              <RefreshCw className="h-3 w-3" /> Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {!runs || runs.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <Activity className="h-8 w-8 mx-auto mb-3 opacity-30" />
              <p className="text-sm">No runs yet. Start your first healthcheck above.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {runs.map((run) => (
                <div
                  key={run.id}
                  className="flex items-center justify-between rounded-lg border border-border bg-secondary/30 px-4 py-3"
                >
                  <div className="flex items-center gap-3">
                    <Badge
                      className={`text-xs border ${
                        run.status === "completed"
                          ? "bg-green-500/10 text-green-400 border-green-500/30"
                          : run.status === "failed"
                          ? "bg-destructive/10 text-destructive border-destructive/30"
                          : run.status === "running"
                          ? "bg-blue-500/10 text-blue-400 border-blue-500/30"
                          : "bg-muted text-muted-foreground border-border"
                      }`}
                    >
                      {run.status}
                    </Badge>
                    <div>
                      <p className="text-sm font-medium">Run #{run.id}</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {new Date(run.startedAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right text-xs text-muted-foreground">
                    {run.totalFindings != null && (
                      <p>{run.totalFindings} findings</p>
                    )}
                    {run.durationMs != null && (
                      <p>{(run.durationMs / 1000).toFixed(1)}s</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
