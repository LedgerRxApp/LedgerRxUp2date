import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { Activity, ArrowRight, Bot, ShieldCheck } from "lucide-react";
import { useEffect } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect authenticated users directly to the dashboard
  useEffect(() => {
    if (!loading && user) {
      setLocation("/dashboard");
    }
  }, [user, loading, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="h-6 w-6 rounded-full border-2 border-primary border-t-transparent animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Header */}
      <header className="border-b border-border px-6 py-4 flex items-center justify-between">
        <span className="font-bold text-xl text-primary tracking-tight">LedgerRx</span>
        <Button
          onClick={() => { window.location.href = getLoginUrl(); }}
          size="sm"
        >
          Sign in
        </Button>
      </header>

      {/* Hero */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 py-20 text-center">
        <div className="max-w-2xl space-y-6">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm text-primary font-medium">
            <ShieldCheck className="h-4 w-4" />
            QuickBooks Diagnostic &amp; Cleanup Copilot
          </div>

          <h1 className="text-5xl font-bold tracking-tight leading-tight">
            Fix your books.<br />
            <span className="text-primary">Automatically.</span>
          </h1>

          <p className="text-lg text-muted-foreground leading-relaxed">
            LedgerRx connects to QuickBooks Online, runs a comprehensive
            healthcheck across your accounting data, surfaces findings by
            severity, and guides you through cleanup with an AI-powered copilot.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
            <Button
              size="lg"              onClick={() => { window.location.href = getLoginUrl(); }}    className="gap-2"
            >
              Get started <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Feature grid */}
        <div className="mt-20 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl w-full text-left">
          {[
            {
              icon: Activity,
              title: "Healthcheck",
              desc: "Automated diagnostic checks across transactions, vendors, customers, and accounts.",
            },
            {
              icon: ShieldCheck,
              title: "Findings",
              desc: "Prioritised findings by severity — critical, warning, and informational.",
            },
            {
              icon: Bot,
              title: "Copilot",
              desc: "AI-generated cleanup suggestions with one-click apply actions.",
            },
          ].map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="rounded-xl border border-border bg-card p-5 space-y-3"
            >
              <div className="h-9 w-9 rounded-lg bg-primary/15 flex items-center justify-center">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </main>

      <footer className="border-t border-border px-6 py-4 text-center text-xs text-muted-foreground">
        LedgerRx — Phase 1 Scaffold
      </footer>
    </div>
  );
}
