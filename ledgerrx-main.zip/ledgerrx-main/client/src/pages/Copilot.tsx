import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Bot, CheckCircle2, Loader2, Sparkles, XCircle } from "lucide-react";
import { toast } from "sonner";

export default function Copilot() {
  return (
    <DashboardLayout>
      <CopilotContent />
    </DashboardLayout>
  );
}

const ACTION_TYPE_STYLES: Record<string, string> = {
  auto_fix: "bg-green-500/10 text-green-400 border-green-500/30",
  manual_step: "bg-amber-500/10 text-amber-400 border-amber-500/30",
  review_required: "bg-blue-500/10 text-blue-400 border-blue-500/30",
};

function CopilotContent() {
  const utils = trpc.useUtils();
  const { data: suggestions, isLoading } = trpc.copilot.listSuggestions.useQuery();

  const updateStatus = trpc.copilot.updateStatus.useMutation({
    onSuccess: () => {
      utils.copilot.listSuggestions.invalidate();
      toast.success("Suggestion updated.");
    },
    onError: (err) => toast.error(err.message),
  });

  const pending = suggestions?.filter((s) => s.status === "pending") ?? [];
  const actioned = suggestions?.filter((s) => s.status !== "pending") ?? [];

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Cleanup Copilot</h1>
        <p className="text-muted-foreground text-sm mt-1">
          AI-generated suggestions for resolving your QuickBooks findings.
        </p>
      </div>

      {/* Phase 3 notice */}
      <div className="rounded-lg border border-primary/20 bg-primary/5 p-4 flex gap-3">
        <Sparkles className="h-5 w-5 text-primary shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="text-sm font-medium text-primary">Phase 1 Scaffold</p>
          <p className="text-xs text-muted-foreground leading-relaxed">
            The Copilot data model and UI are scaffolded. AI suggestion generation
            (using the built-in LLM) will be implemented in Phase 3 after the
            diagnostic execution engine (Phase 2) is complete.
          </p>
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center gap-2 text-muted-foreground py-10">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span className="text-sm">Loading suggestions…</span>
        </div>
      ) : pending.length === 0 && actioned.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Bot className="h-10 w-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm font-medium">No suggestions yet</p>
          <p className="text-xs mt-1">
            Suggestions will appear here after running a healthcheck and
            triggering the Copilot in Phase 3.
          </p>
        </div>
      ) : (
        <>
          {pending.length > 0 && (
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  Pending Suggestions
                  <Badge className="bg-muted text-muted-foreground border-border text-xs">
                    {pending.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {pending.map((s) => (
                  <div
                    key={s.id}
                    className="rounded-lg border border-border bg-secondary/30 px-4 py-3 space-y-2"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-medium">{s.actionTitle}</p>
                        {s.explanation && (
                          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                            {s.explanation}
                          </p>
                        )}
                      </div>
                      <Badge className={`text-xs border shrink-0 ${ACTION_TYPE_STYLES[s.actionType]}`}>
                        {s.actionType.replace("_", " ")}
                      </Badge>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs gap-1"
                        onClick={() => updateStatus.mutate({ id: s.id, status: "accepted" })}
                        disabled={updateStatus.isPending}
                      >
                        <CheckCircle2 className="h-3 w-3" /> Accept
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 text-xs gap-1 text-muted-foreground"
                        onClick={() => updateStatus.mutate({ id: s.id, status: "rejected" })}
                        disabled={updateStatus.isPending}
                      >
                        <XCircle className="h-3 w-3" /> Reject
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {actioned.length > 0 && (
            <Card className="border-border opacity-70">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-muted-foreground">
                  Actioned
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {actioned.map((s) => (
                  <div
                    key={s.id}
                    className="flex items-center justify-between rounded-lg border border-border bg-secondary/20 px-4 py-3"
                  >
                    <p className="text-sm text-muted-foreground line-through">
                      {s.actionTitle}
                    </p>
                    <Badge className="text-xs border bg-muted text-muted-foreground border-border">
                      {s.status}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
