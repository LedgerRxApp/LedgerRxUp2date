import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { trpc } from "@/lib/trpc";
import {
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  Loader2,
  Settings as SettingsIcon,
  Unplug,
  Wifi,
  WifiOff,
} from "lucide-react";
import { toast } from "sonner";

export default function Settings() {
  return (
    <DashboardLayout>
      <SettingsContent />
    </DashboardLayout>
  );
}

function SettingsContent() {
  const utils = trpc.useUtils();
  const { data: credStatus } = trpc.qbo.credentialsReady.useQuery();
  const { data: qboStatus, isLoading: qboLoading, refetch: refetchQbo } =
    trpc.qbo.status.useQuery();

  const connectMutation = trpc.qbo.getConnectUrl.useMutation({
    onSuccess: ({ url }) => { window.location.href = url; },
    onError: (err) => toast.error(err.message),
  });

  const disconnectMutation = trpc.qbo.disconnect.useMutation({
    onSuccess: () => {
      toast.success("QuickBooks disconnected.");
      refetchQbo();
      utils.qbo.status.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const credentialsConfigured = credStatus?.configured ?? false;
  const isConnected = qboStatus?.connected ?? false;

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Manage your QuickBooks connection and application configuration.
        </p>
      </div>

      {/* ── QuickBooks Integration ───────────────────────────────────────────── */}
      <Card className="border-border">
        <CardHeader>
          <div className="flex items-center gap-2">
            <SettingsIcon className="h-4 w-4 text-muted-foreground" />
            <CardTitle className="text-base">QuickBooks Integration</CardTitle>
          </div>
          <CardDescription>
            OAuth 2.0 connection to your QuickBooks Online company.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Credentials status */}
          <div className="rounded-lg border border-border bg-secondary/30 p-4 space-y-3">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
              Environment Configuration
            </p>
            {[
              { key: "QBO_CLIENT_ID", label: "Client ID" },
              { key: "QBO_CLIENT_SECRET", label: "Client Secret" },
              { key: "QBO_REDIRECT_URI", label: "Redirect URI" },
            ].map(({ key, label }) => (
              <div key={key} className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">{label}</p>
                  <code className="text-xs text-muted-foreground font-mono">{key}</code>
                </div>
                {credentialsConfigured ? (
                  <Badge className="bg-green-500/10 text-green-400 border-green-500/30 text-xs">
                    <CheckCircle2 className="h-3 w-3 mr-1" /> Set
                  </Badge>
                ) : (
                  <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/30 text-xs">
                    <AlertTriangle className="h-3 w-3 mr-1" /> Missing
                  </Badge>
                )}
              </div>
            ))}
          </div>

          {!credentialsConfigured && (
            <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-4 space-y-2">
              <p className="text-sm font-medium text-amber-300">Credentials required</p>
              <p className="text-xs text-amber-400/80 leading-relaxed">
                Add the three environment variables above to your{" "}
                <code className="font-mono bg-amber-500/20 px-1 rounded">.env</code> file and restart
                the server. See the README for the exact redirect URI to register in Intuit.
              </p>
              <p className="text-xs text-amber-400/80 font-mono bg-amber-500/10 rounded p-2 border border-amber-500/20">
                QBO_REDIRECT_URI=https://&lt;your-domain&gt;/api/qbo/callback
              </p>
            </div>
          )}

          <Separator className="bg-border" />

          {/* Connection status */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {qboLoading ? (
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              ) : isConnected ? (
                <Wifi className="h-4 w-4 text-green-400" />
              ) : (
                <WifiOff className="h-4 w-4 text-muted-foreground" />
              )}
              <div>
                <p className="text-sm font-medium">
                  {isConnected
                    ? qboStatus?.connection?.companyName ?? "Connected"
                    : "Not connected"}
                </p>
                {isConnected && qboStatus?.connection && (
                  <p className="text-xs text-muted-foreground font-mono">
                    Realm: {qboStatus.connection.realmId}
                  </p>
                )}
              </div>
            </div>

            {isConnected ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => disconnectMutation.mutate()}
                disabled={disconnectMutation.isPending}
                className="gap-2 text-muted-foreground hover:text-destructive"
              >
                {disconnectMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Unplug className="h-4 w-4" />
                )}
                Disconnect
              </Button>
            ) : (
              <Button
                size="sm"
                onClick={() => connectMutation.mutate()}
                disabled={connectMutation.isPending || !credentialsConfigured}
                className="gap-2"
              >
                {connectMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ExternalLink className="h-4 w-4" />
                )}
                Connect
              </Button>
            )}
          </div>

          {isConnected && qboStatus?.connection?.accessTokenExpiresAt && (
            <p className="text-xs text-muted-foreground">
              Access token expires:{" "}
              {new Date(qboStatus.connection.accessTokenExpiresAt).toLocaleString()}
            </p>
          )}
        </CardContent>
      </Card>

      {/* ── Intuit Developer Portal link ─────────────────────────────────────── */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-base">Intuit Developer Portal</CardTitle>
          <CardDescription>
            Manage your QuickBooks app credentials and redirect URIs.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button
            variant="outline"
            size="sm"
            className="gap-2"
            onClick={() => window.open("https://developer.intuit.com/app/developer/myapps", "_blank")}
          >
            <ExternalLink className="h-4 w-4" />
            Open Intuit Developer Portal
          </Button>
          <p className="text-xs text-muted-foreground mt-3 leading-relaxed">
            Register the redirect URI{" "}
            <code className="font-mono bg-secondary px-1 rounded">
              https://&lt;your-domain&gt;/api/qbo/callback
            </code>{" "}
            under your app's <strong>Keys &amp; OAuth</strong> settings.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
