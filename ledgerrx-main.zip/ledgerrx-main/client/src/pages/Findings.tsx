import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import {
  AlertTriangle,
  CheckCircle2,
  Info,
  Loader2,
  ShieldAlert,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";

export default function Findings() {
  return (
    <DashboardLayout>
      <FindingsContent />
    </DashboardLayout>
  );
}

const SEVERITY_CONFIG = {
  critical: {
    icon: XCircle,
    badge: "bg-destructive/10 text-destructive border-destructive/30",
    label: "Critical",
  },
  warning: {
    icon: AlertTriangle,
    badge: "bg-amber-500/10 text-amber-400 border-amber-500/30",
    label: "Warning",
  },
  info: {
    icon: Info,
    badge: "bg-blue-500/10 text-blue-400 border-blue-500/30",
    label: "Info",
  },
} as const;

function FindingsContent() {
  const utils = trpc.useUtils();
  const { data: findings, isLoading } = trpc.findings.list.useQuery();

  const updateStatus = trpc.findings.updateStatus.useMutation({
    onSuccess: () => {
      utils.findings.list.invalidate();
      toast.success("Finding updated.");
    },
    onError: (err) => toast.error(err.message),
  });

  const open = findings?.filter((f) => f.status === "open") ?? [];
  const resolved = findings?.filter((f) => f.status !== "open") ?? [];

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Findings</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Diagnostic findings from your QuickBooks healthchecks.
        </p>
      </div>

      {isLoading ? (
        <div className="flex items-center gap-2 text-muted-foreground py-10">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span className="text-sm">Loading findings…</span>
        </div>
      ) : open.length === 0 && resolved.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <ShieldAlert className="h-10 w-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm font-medium">No findings yet</p>
          <p className="text-xs mt-1">
            Run a healthcheck from the Dashboard to surface findings.
          </p>
        </div>
      ) : (
        <>
          {/* Open findings */}
          {open.length > 0 && (
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  Open Findings
                  <Badge className="bg-muted text-muted-foreground border-border text-xs">
                    {open.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {open.map((finding) => {
                  const cfg = SEVERITY_CONFIG[finding.severity];
                  const Icon = cfg.icon;
                  return (
                    <div
                      key={finding.id}
                      className="flex items-start justify-between rounded-lg border border-border bg-secondary/30 px-4 py-3 gap-3"
                    >
                      <div className="flex items-start gap-3 min-w-0">
                        <Icon className={`h-4 w-4 mt-0.5 shrink-0 ${
                          finding.severity === "critical" ? "text-destructive"
                          : finding.severity === "warning" ? "text-amber-400"
                          : "text-blue-400"
                        }`} />
                        <div className="min-w-0">
                          <p className="text-sm font-medium">{finding.title}</p>
                          {finding.description && (
                            <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                              {finding.description}
                            </p>
                          )}
                          <div className="flex items-center gap-2 mt-1.5">
                            <Badge className={`text-xs border ${cfg.badge}`}>
                              {cfg.label}
                            </Badge>
                            {finding.affectedCount != null && finding.affectedCount > 0 && (
                              <span className="text-xs text-muted-foreground">
                                {finding.affectedCount} affected
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-1.5 shrink-0">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 text-xs gap-1"
                          onClick={() =>
                            updateStatus.mutate({ id: finding.id, status: "resolved" })
                          }
                          disabled={updateStatus.isPending}
                        >
                          <CheckCircle2 className="h-3 w-3" /> Resolve
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 text-xs text-muted-foreground"
                          onClick={() =>
                            updateStatus.mutate({ id: finding.id, status: "dismissed" })
                          }
                          disabled={updateStatus.isPending}
                        >
                          Dismiss
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          )}

          {/* Resolved / dismissed */}
          {resolved.length > 0 && (
            <Card className="border-border opacity-70">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-muted-foreground flex items-center gap-2">
                  Resolved / Dismissed
                  <Badge className="bg-muted text-muted-foreground border-border text-xs">
                    {resolved.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {resolved.map((finding) => (
                  <div
                    key={finding.id}
                    className="flex items-center justify-between rounded-lg border border-border bg-secondary/20 px-4 py-3"
                  >
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="h-4 w-4 text-muted-foreground shrink-0" />
                      <p className="text-sm text-muted-foreground line-through">
                        {finding.title}
                      </p>
                    </div>
                    <Badge className="text-xs border bg-muted text-muted-foreground border-border">
                      {finding.status}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
