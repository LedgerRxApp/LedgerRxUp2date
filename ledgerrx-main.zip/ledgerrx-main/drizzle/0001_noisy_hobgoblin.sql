CREATE TABLE `copilot_suggestions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`findingId` int NOT NULL,
	`userId` int NOT NULL,
	`actionTitle` varchar(255) NOT NULL,
	`explanation` text,
	`actionType` enum('auto_fix','manual_step','review_required') NOT NULL DEFAULT 'review_required',
	`status` enum('pending','accepted','rejected','applied') NOT NULL DEFAULT 'pending',
	`payload` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`appliedAt` timestamp,
	CONSTRAINT `copilot_suggestions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `findings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`healthcheckRunId` int NOT NULL,
	`userId` int NOT NULL,
	`checkKey` varchar(128) NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`severity` enum('critical','warning','info') NOT NULL DEFAULT 'warning',
	`status` enum('open','resolved','dismissed') NOT NULL DEFAULT 'open',
	`metadata` json,
	`affectedCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`resolvedAt` timestamp,
	CONSTRAINT `findings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `healthcheck_runs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`qboConnectionId` int NOT NULL,
	`status` enum('pending','running','completed','failed') NOT NULL DEFAULT 'pending',
	`totalChecks` int DEFAULT 0,
	`totalFindings` int DEFAULT 0,
	`durationMs` int,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	`errorMessage` text,
	CONSTRAINT `healthcheck_runs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `qbo_connections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`realmId` varchar(64) NOT NULL,
	`companyName` varchar(255),
	`accessToken` text,
	`refreshToken` text,
	`accessTokenExpiresAt` timestamp,
	`refreshTokenExpiresAt` timestamp,
	`isActive` boolean NOT NULL DEFAULT true,
	`connectedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `qbo_connections_id` PRIMARY KEY(`id`)
);
