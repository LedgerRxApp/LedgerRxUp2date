import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  json,
  boolean,
} from "drizzle-orm/mysql-core";

// ─── Core Users ────────────────────────────────────────────────────────────────

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── QuickBooks Connections ────────────────────────────────────────────────────
// Stores OAuth tokens and realm metadata per user.
// accessToken and refreshToken are stored as text; encrypt at rest in production.

export const qboConnections = mysqlTable("qbo_connections", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** QuickBooks company/realm identifier returned during OAuth */
  realmId: varchar("realmId", { length: 64 }).notNull(),
  companyName: varchar("companyName", { length: 255 }),
  /** OAuth access token — treat as secret, never expose to client */
  accessToken: text("accessToken"),
  /** OAuth refresh token — treat as secret, never expose to client */
  refreshToken: text("refreshToken"),
  /** UTC timestamp when the access token expires */
  accessTokenExpiresAt: timestamp("accessTokenExpiresAt"),
  /** UTC timestamp when the refresh token expires */
  refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt"),
  /** Whether this connection is currently active */
  isActive: boolean("isActive").default(true).notNull(),
  connectedAt: timestamp("connectedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type QboConnection = typeof qboConnections.$inferSelect;
export type InsertQboConnection = typeof qboConnections.$inferInsert;

// ─── Healthcheck Runs ──────────────────────────────────────────────────────────
// Each time a user triggers a diagnostic run, a record is created here.

export const healthcheckRuns = mysqlTable("healthcheck_runs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  qboConnectionId: int("qboConnectionId").notNull(),
  /** pending | running | completed | failed */
  status: mysqlEnum("status", ["pending", "running", "completed", "failed"])
    .default("pending")
    .notNull(),
  /** Summary counts after run completes */
  totalChecks: int("totalChecks").default(0),
  totalFindings: int("totalFindings").default(0),
  /** ISO duration string or seconds elapsed */
  durationMs: int("durationMs"),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  errorMessage: text("errorMessage"),
});

export type HealthcheckRun = typeof healthcheckRuns.$inferSelect;
export type InsertHealthcheckRun = typeof healthcheckRuns.$inferInsert;

// ─── Findings ─────────────────────────────────────────────────────────────────
// Individual diagnostic findings surfaced during a healthcheck run.

export const findings = mysqlTable("findings", {
  id: int("id").autoincrement().primaryKey(),
  healthcheckRunId: int("healthcheckRunId").notNull(),
  userId: int("userId").notNull(),
  /** Module that produced this finding: e.g. "uncategorized_txns", "duplicate_vendors" */
  checkKey: varchar("checkKey", { length: 128 }).notNull(),
  /** Human-readable title */
  title: varchar("title", { length: 255 }).notNull(),
  /** Full description of the issue */
  description: text("description"),
  /** critical | warning | info */
  severity: mysqlEnum("severity", ["critical", "warning", "info"])
    .default("warning")
    .notNull(),
  /** open | resolved | dismissed */
  status: mysqlEnum("status", ["open", "resolved", "dismissed"])
    .default("open")
    .notNull(),
  /** Arbitrary JSON payload — entity IDs, amounts, counts, etc. */
  metadata: json("metadata"),
  /** Number of affected records */
  affectedCount: int("affectedCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
});

export type Finding = typeof findings.$inferSelect;
export type InsertFinding = typeof findings.$inferInsert;

// ─── Copilot Suggestions ──────────────────────────────────────────────────────
// AI-generated cleanup suggestions linked to one or more findings.

export const copilotSuggestions = mysqlTable("copilot_suggestions", {
  id: int("id").autoincrement().primaryKey(),
  findingId: int("findingId").notNull(),
  userId: int("userId").notNull(),
  /** Short action title shown in the UI */
  actionTitle: varchar("actionTitle", { length: 255 }).notNull(),
  /** Full explanation of the suggested fix */
  explanation: text("explanation"),
  /** Type of action: auto_fix | manual_step | review_required */
  actionType: mysqlEnum("actionType", ["auto_fix", "manual_step", "review_required"])
    .default("review_required")
    .notNull(),
  /** pending | accepted | rejected | applied */
  status: mysqlEnum("status", ["pending", "accepted", "rejected", "applied"])
    .default("pending")
    .notNull(),
  /** Structured payload describing the fix operation (scaffold — no logic yet) */
  payload: json("payload"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  appliedAt: timestamp("appliedAt"),
});

export type CopilotSuggestion = typeof copilotSuggestions.$inferSelect;
export type InsertCopilotSuggestion = typeof copilotSuggestions.$inferInsert;
