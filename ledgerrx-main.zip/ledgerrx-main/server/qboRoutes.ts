/**
 * qboRoutes.ts
 *
 * Registers the QuickBooks OAuth callback as an Express route.
 * This must be an Express route (not tRPC) because Intuit redirects the
 * browser here with query parameters — it is not a JSON API call.
 *
 * Route:  GET /api/qbo/callback
 *
 * Flow:
 *   1. Intuit redirects user to /api/qbo/callback?code=...&realmId=...&state=...
 *   2. We exchange the code for tokens via exchangeCodeForTokens()
 *   3. We upsert the connection record in the database
 *   4. We redirect the user to the dashboard
 *
 * ─── CREDENTIAL GATE ──────────────────────────────────────────────────────────
 * If QBO_CLIENT_ID / QBO_CLIENT_SECRET are not set, the callback will return
 * a 503 with a clear error message rather than silently failing.
 */

import type { Express, Request, Response } from "express";
import { sdk } from "./_core/sdk";
import {
  areCredentialsConfigured,
  exchangeCodeForTokens,
  upsertConnection,
} from "./modules/qbo";

export function registerQboRoutes(app: Express): void {
  /**
   * GET /api/qbo/callback
   *
   * Handles the OAuth redirect from Intuit after the user authorizes the app.
   */
  app.get("/api/qbo/callback", async (req: Request, res: Response) => {
    // ── Credential guard ────────────────────────────────────────────────────
    if (!areCredentialsConfigured()) {
      res.status(503).send(
        "QuickBooks OAuth is not configured. " +
          "Add QBO_CLIENT_ID, QBO_CLIENT_SECRET, and QBO_REDIRECT_URI to your .env file, " +
          "then restart the server."
      );
      return;
    }

    // ── Error from Intuit ───────────────────────────────────────────────────
    if (req.query.error) {
      const errorMsg = req.query.error_description ?? req.query.error;
      console.error("[QBO OAuth] Intuit returned error:", errorMsg);
      res.redirect(
        `/?qbo_error=${encodeURIComponent(String(errorMsg))}`
      );
      return;
    }

    // ── Validate required params ────────────────────────────────────────────
    const { code, realmId, state } = req.query as Record<string, string>;

    if (!code || !realmId) {
      res.status(400).send("Missing required OAuth parameters (code, realmId).");
      return;
    }

    // ── Authenticate the session user ───────────────────────────────────────
    let user;
    try {
      user = await sdk.authenticateRequest(req);
    } catch {
      // Not logged in — redirect to login
      res.redirect("/");
      return;
    }

    try {
      // ── Exchange code for tokens ──────────────────────────────────────────
      const tokens = await exchangeCodeForTokens(code, realmId);

      const now = new Date();
      const accessTokenExpiresAt = new Date(
        now.getTime() + tokens.expires_in * 1000
      );
      const refreshTokenExpiresAt = new Date(
        now.getTime() + tokens.x_refresh_token_expires_in * 1000
      );

      // ── Persist the connection ────────────────────────────────────────────
      await upsertConnection({
        userId: user.id,
        realmId: tokens.realmId,
        accessToken: tokens.access_token,
        refreshToken: tokens.refresh_token,
        accessTokenExpiresAt,
        refreshTokenExpiresAt,
        isActive: true,
      });

      console.log(
        `[QBO OAuth] User ${user.id} connected realmId=${realmId}`
      );

      // ── Redirect to dashboard with success indicator ──────────────────────
      res.redirect("/dashboard?qbo_connected=1");
    } catch (err) {
      console.error("[QBO OAuth] Callback error:", err);
      const message =
        err instanceof Error ? err.message : "Unknown error during OAuth";
      res.redirect(
        `/dashboard?qbo_error=${encodeURIComponent(message)}`
      );
    }
  });
}
