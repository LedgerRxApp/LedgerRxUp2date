/**
 * sync router  [SCAFFOLD — Phase 2]
 *
 * Exposes QBO data sync controls to the frontend.
 * Actual sync execution is deferred to Phase 2.
 */

import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "../_core/trpc";
import { getActiveConnection } from "../modules/qbo";

export const syncRouter = router({
  /**
   * Triggers a QBO data sync for the authenticated user.
   * [SCAFFOLD] — Implementation deferred to Phase 2.
   */
  trigger: protectedProcedure.mutation(async ({ ctx }) => {
    const connection = await getActiveConnection(ctx.user.id);

    if (!connection) {
      throw new TRPCError({
        code: "PRECONDITION_FAILED",
        message: "No active QuickBooks connection. Connect QuickBooks first.",
      });
    }

    // Phase 2: call syncConnection(connection) here
    throw new TRPCError({
      code: "METHOD_NOT_SUPPORTED",
      message: "QBO sync is not yet implemented. Coming in Phase 2.",
    });
  }),
});
