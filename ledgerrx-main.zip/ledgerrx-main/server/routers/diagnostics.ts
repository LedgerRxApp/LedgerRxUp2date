/**
 * routers/diagnostics.ts
 *
 * tRPC router for diagnostic healthcheck execution.
 * Wires the QBO API client, diagnostic engine, and findings generator
 * into a single end-to-end healthcheck procedure.
 */

import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { getDb } from "../db";
import { healthcheckRuns, type InsertHealthcheckRun } from "../../drizzle/schema";
import { getActiveConnection } from "../modules/qbo";
import { createQboApiClient } from "../modules/qbo/api";
import { HardenedDiagnosticEngine } from "../modules/diagnostics/checks";
import { FindingsGenerator, generateFindingsSummary } from "../modules/findings/generator";
import { eq } from "drizzle-orm";

export const diagnosticsRouter = router({
  /**
   * Runs a complete healthcheck against the user's QuickBooks data.
   *
   * Process:
   * 1. Verify QBO connection exists and is active
   * 2. Create a healthcheck run record
   * 3. Fetch P&L, Balance Sheet, GL, and transactions from QBO
   * 4. Execute diagnostic checks in proper order
   * 5. Generate findings and persist to database
   * 6. Return findings summary
   *
   * This is a long-running operation (may take 30-60 seconds for large datasets).
   */
  runHealthcheck: protectedProcedure
    .input(
      z.object({
        startDate: z.string().optional(),
        endDate: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Database not available",
        });
      }

      // Default date range: last 90 days
      const endDate = input.endDate || new Date().toISOString().split("T")[0]!;
      const startDate =
        input.startDate ||
        new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]!;

      // Step 1: Verify QBO connection
      const connection = await getActiveConnection(ctx.user.id);
      if (!connection) {
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message: "No active QuickBooks connection. Please connect first.",
        });
      }

      // Step 2: Create healthcheck run record
      const runRecord: InsertHealthcheckRun = {
        userId: ctx.user.id,
        qboConnectionId: connection.id,
        status: "running",
        startedAt: new Date(),
      };

      const insertResult = await db.insert(healthcheckRuns).values(runRecord);
      const runId = (insertResult as any)[0] as number;

      try {
        // Step 3: Create QBO API client
        const qboClient = await createQboApiClient(ctx.user.id, "sandbox");
        if (!qboClient) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create QBO API client",
          });
        }

        // Step 4: Run diagnostics
        const startTime = Date.now();
        const diagnosticEngine = new HardenedDiagnosticEngine(qboClient);
        const findings = await diagnosticEngine.runDiagnostics(startDate, endDate, endDate);
        const durationMs = Date.now() - startTime;

        // Step 5: Generate and persist findings
        const findingsGenerator = new FindingsGenerator();
        const persistResult = await findingsGenerator.generateAndPersistFindings(
          runId,
          ctx.user.id,
          findings
        );

        // Step 6: Update healthcheck run with results
        await db
          .update(healthcheckRuns)
          .set({
            status: "completed",
            totalChecks: findings.length,
            totalFindings: persistResult.totalFindings,
            durationMs,
            completedAt: new Date(),
          })
          .where(eq(healthcheckRuns.id, runId));

        // Return summary
        const summary = generateFindingsSummary(findings);

        return {
          success: true,
          runId,
          durationMs,
          findingsSummary: summary,
          findings: findings.map((f: any) => ({
            title: f.title,
            severity: f.severity,
            whyItMatters: f.whyItMatters,
            impactedReports: f.impactedReports,
            impactedAccounts: f.impactedAccounts,
            evidenceSummary: f.evidenceSummary,
            confidence: f.confidence,
            recommendedAction: f.recommendedAction,
            suitableForGuidedCorrection: f.suitableForGuidedCorrection,
          })),
        };
      } catch (error) {
        // Mark run as failed
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        await db
          .update(healthcheckRuns)
          .set({
            status: "failed",
            errorMessage,
            completedAt: new Date(),
          })
          .where(eq(healthcheckRuns.id, runId));

        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: `Healthcheck failed: ${errorMessage}`,
        });
      }
    }),

  /**
   * Gets the status of a healthcheck run.
   */
  getRunStatus: protectedProcedure
    .input(z.object({ runId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Database not available",
        });
      }

      const run = await db
        .select()
        .from(healthcheckRuns)
        .where(eq(healthcheckRuns.id, input.runId))
        .limit(1);

      if (!run[0]) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Healthcheck run not found",
        });
      }

      return run[0];
    }),

  /**
   * Lists recent healthcheck runs for the user.
   */
  listRuns: protectedProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(50).default(10),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      const runs = await db
        .select()
        .from(healthcheckRuns)
        .where(eq(healthcheckRuns.userId, ctx.user.id))
        .orderBy((t) => t.startedAt)
        .limit(input.limit);

      return runs;
    }),
});
