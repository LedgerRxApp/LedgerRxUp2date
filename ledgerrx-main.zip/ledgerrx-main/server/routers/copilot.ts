/**
 * copilot router  [SCAFFOLD — Phase 3]
 *
 * Exposes AI-generated cleanup suggestions to the frontend.
 * LLM integration and suggestion generation are deferred to Phase 3.
 */

import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  getSuggestionsByFinding,
  getSuggestionsByUser,
  updateSuggestionStatus,
} from "../modules/copilot";

export const copilotRouter = router({
  /**
   * Lists all copilot suggestions for the authenticated user.
   */
  listSuggestions: protectedProcedure.query(async ({ ctx }) => {
    return getSuggestionsByUser(ctx.user.id);
  }),

  /**
   * Returns suggestions for a specific finding.
   */
  getSuggestionsForFinding: protectedProcedure
    .input(z.object({ findingId: z.number().int().positive() }))
    .query(async ({ ctx: _ctx, input }) => {
      return getSuggestionsByFinding(input.findingId);
    }),

  /**
   * Accepts or rejects a suggestion.
   */
  updateStatus: protectedProcedure
    .input(
      z.object({
        id: z.number().int().positive(),
        status: z.enum(["accepted", "rejected"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await updateSuggestionStatus(input.id, ctx.user.id, input.status);
      return { success: true };
    }),

  /**
   * Triggers AI suggestion generation for a finding.
   * [SCAFFOLD] — LLM integration wired in Phase 3.
   */
  generateForFinding: protectedProcedure
    .input(z.object({ findingId: z.number().int().positive() }))
    .mutation(async () => {
      throw new TRPCError({
        code: "NOT_IMPLEMENTED" as never,
        message:
          "Copilot suggestion generation is not yet implemented. Coming in Phase 3.",
      });
    }),
});
