import { describe, it, expect, beforeEach } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";
import type { User } from "../../drizzle/schema";

describe("qbo credentials validation", () => {
  let ctx: TrpcContext;
  let mockUser: User;

  beforeEach(() => {
    mockUser = {
      id: 1,
      openId: "test-user-123",
      name: "Test User",
      email: "test@example.com",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    };

    ctx = {
      user: mockUser,
      req: {
        protocol: "https",
        headers: {},
      } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
  });

  it("credentialsReady returns configured: true when all required env vars are set", async () => {
    const caller = appRouter.createCaller(ctx);
    const result = await caller.qbo.credentialsReady();

    // Credentials should be configured if all three env vars are present
    expect(result.configured).toBe(
      !!(
        process.env.QBO_CLIENT_ID &&
        process.env.QBO_CLIENT_SECRET &&
        process.env.QBO_REDIRECT_URI
      )
    );
  });

  it("getConnectUrl returns a valid OAuth URL when credentials are configured", async () => {
    // Only run this test if credentials are actually set
    if (
      !process.env.QBO_CLIENT_ID ||
      !process.env.QBO_CLIENT_SECRET ||
      !process.env.QBO_REDIRECT_URI
    ) {
      console.log("Skipping OAuth URL test — credentials not configured");
      expect(true).toBe(true);
      return;
    }

    const caller = appRouter.createCaller(ctx);
    const result = await caller.qbo.getConnectUrl();

    expect(result).toHaveProperty("url");
    expect(result.url).toContain("https://");
    expect(result.url).toContain("oauth");
  });
});
