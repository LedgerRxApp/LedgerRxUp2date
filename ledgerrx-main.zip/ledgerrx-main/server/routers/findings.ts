/**
 * findings router
 *
 * Exposes diagnostic findings to the frontend.
 */

import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  getFindingsByUser,
  getFindingsByRun,
  getFindingById,
  updateFindingStatus,
} from "../modules/findings";

export const findingsRouter = router({
  /**
   * Lists all findings for the authenticated user, newest first.
   */
  list: protectedProcedure
    .input(
      z
        .object({
          healthcheckRunId: z.number().int().positive().optional(),
          severity: z.enum(["critical", "warning", "info"]).optional(),
          status: z.enum(["open", "resolved", "dismissed"]).optional(),
        })
        .optional()
    )
    .query(async ({ ctx, input }) => {
      if (input?.healthcheckRunId) {
        return getFindingsByRun(input.healthcheckRunId);
      }
      const all = await getFindingsByUser(ctx.user.id);

      // Apply optional filters
      return all.filter((f) => {
        if (input?.severity && f.severity !== input.severity) return false;
        if (input?.status && f.status !== input.status) return false;
        return true;
      });
    }),

  /**
   * Returns a single finding by ID.
   */
  get: protectedProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const finding = await getFindingById(input.id, ctx.user.id);
      if (!finding) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Finding not found" });
      }
      return finding;
    }),

  /**
   * Updates the status of a finding (resolve or dismiss).
   */
  updateStatus: protectedProcedure
    .input(
      z.object({
        id: z.number().int().positive(),
        status: z.enum(["resolved", "dismissed"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await updateFindingStatus(input.id, ctx.user.id, input.status);
      return { success: true };
    }),
});
