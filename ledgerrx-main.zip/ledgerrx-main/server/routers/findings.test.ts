import { describe, it, expect, beforeEach } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";
import type { User } from "../../drizzle/schema";

describe("findings router", () => {
  let ctx: TrpcContext;
  let mockUser: User;

  beforeEach(() => {
    mockUser = {
      id: 1,
      openId: "test-user-123",
      name: "Test User",
      email: "test@example.com",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    };

    ctx = {
      user: mockUser,
      req: {
        protocol: "https",
        headers: {},
      } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
  });

  describe("findings.list", () => {
    it("returns an empty array when no findings exist", async () => {
      const caller = appRouter.createCaller(ctx);
      const result = await caller.findings.list();

      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBe(0);
    });

    it("accepts optional filters", async () => {
      const caller = appRouter.createCaller(ctx);
      const result = await caller.findings.list({
        severity: "critical",
        status: "open",
      });

      expect(Array.isArray(result)).toBe(true);
    });
  });
});
