import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";
import type { User } from "../../drizzle/schema";

describe("qbo router", () => {
  let ctx: TrpcContext;
  let mockUser: User;

  beforeEach(() => {
    mockUser = {
      id: 1,
      openId: "test-user-123",
      name: "Test User",
      email: "test@example.com",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    };

    ctx = {
      user: mockUser,
      req: {
        protocol: "https",
        headers: {},
      } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
  });

  describe("qbo.credentialsReady", () => {
    it("returns configured: false when credentials are missing", async () => {
      // Temporarily clear env vars
      const original = {
        id: process.env.QBO_CLIENT_ID,
        secret: process.env.QBO_CLIENT_SECRET,
        uri: process.env.QBO_REDIRECT_URI,
      };

      delete process.env.QBO_CLIENT_ID;
      delete process.env.QBO_CLIENT_SECRET;
      delete process.env.QBO_REDIRECT_URI;

      try {
        const caller = appRouter.createCaller(ctx);
        const result = await caller.qbo.credentialsReady();
        expect(result.configured).toBe(false);
      } finally {
        // Restore
        if (original.id) process.env.QBO_CLIENT_ID = original.id;
        if (original.secret) process.env.QBO_CLIENT_SECRET = original.secret;
        if (original.uri) process.env.QBO_REDIRECT_URI = original.uri;
      }
    });
  });

  describe("qbo.status", () => {
    it("returns connected: false when no active connection exists", async () => {
      const caller = appRouter.createCaller(ctx);
      const result = await caller.qbo.status();

      expect(result.connected).toBe(false);
      expect(result.connection).toBe(null);
    });
  });

  describe("qbo.disconnect", () => {
    it("returns success: true", async () => {
      const caller = appRouter.createCaller(ctx);
      const result = await caller.qbo.disconnect();

      expect(result.success).toBe(true);
    });
  });
});
