/**
 * qbo router
 *
 * Handles QuickBooks Online OAuth connect flow and connection status.
 *
 * Procedures:
 *   qbo.status          — Returns current connection state for the user
 *   qbo.getConnectUrl   — Builds and returns the Intuit authorization URL
 *   qbo.disconnect      — Deactivates the current QBO connection
 *   qbo.credentialsReady — Returns whether QBO env vars are configured
 *
 * HTTP routes (registered in server/_core/index.ts via Express):
 *   GET /api/qbo/callback — Handles the OAuth redirect from Intuit
 */

import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import {
  areCredentialsConfigured,
  buildAuthorizationUrl,
  deactivateConnection,
  getActiveConnection,
} from "../modules/qbo";

export const qboRouter = router({
  /**
   * Returns whether QBO credentials are present in the environment.
   * Used by the frontend to show the correct "not configured" state.
   */
  credentialsReady: publicProcedure.query(() => {
    return { configured: areCredentialsConfigured() };
  }),

  /**
   * Returns the active QBO connection for the authenticated user.
   * Strips tokens before returning — never expose them to the client.
   */
  status: protectedProcedure.query(async ({ ctx }) => {
    const connection = await getActiveConnection(ctx.user.id);

    if (!connection) {
      return { connected: false as const, connection: null };
    }

    return {
      connected: true as const,
      connection: {
        id: connection.id,
        realmId: connection.realmId,
        companyName: connection.companyName,
        connectedAt: connection.connectedAt,
        accessTokenExpiresAt: connection.accessTokenExpiresAt,
        refreshTokenExpiresAt: connection.refreshTokenExpiresAt,
      },
    };
  }),

  /**
   * Builds the Intuit OAuth authorization URL.
   * The frontend redirects the user to this URL to begin the OAuth flow.
   *
   * @throws PRECONDITION_FAILED if credentials are not configured
   */
  getConnectUrl: protectedProcedure.mutation(() => {
    if (!areCredentialsConfigured()) {
      throw new TRPCError({
        code: "PRECONDITION_FAILED",
        message:
          "QuickBooks credentials are not configured. " +
          "Add QBO_CLIENT_ID, QBO_CLIENT_SECRET, and QBO_REDIRECT_URI to your .env file.",
      });
    }

    const { url, state } = buildAuthorizationUrl();
    return { url, state };
  }),

  /**
   * Disconnects the user's active QBO connection.
   * Does not revoke the token at Intuit (Phase 2: add revokeToken call).
   */
  disconnect: protectedProcedure.mutation(async ({ ctx }) => {
    await deactivateConnection(ctx.user.id);
    return { success: true };
  }),
});
