import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { qboRouter } from "./routers/qbo";
import { findingsRouter } from "./routers/findings";
import { diagnosticsRouter } from "./routers/diagnostics";
import { copilotRouter } from "./routers/copilot";
import { syncRouter } from "./routers/sync";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Feature routers ──────────────────────────────────────────────────────
  qbo: qboRouter,
  findings: findingsRouter,
  diagnostics: diagnosticsRouter,
  copilot: copilotRouter,
  sync: syncRouter,
});

export type AppRouter = typeof appRouter;
