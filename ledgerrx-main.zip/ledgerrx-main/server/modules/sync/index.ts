/**
 * sync module  [SCAFFOLD — Phase 2]
 *
 * Handles incremental data synchronisation from QuickBooks Online.
 * Uses QBO's Change Data Capture (CDC) API to pull only changed entities
 * since the last sync, reducing API quota usage.
 *
 * Phase 2 implementation plan:
 *   1. Store a lastSyncedAt timestamp per connection
 *   2. Call QBO CDC endpoint with the delta window
 *   3. Upsert changed entities into local cache tables
 *   4. Trigger diagnostic re-evaluation on changed entities
 *
 * Entities to sync (Phase 2):
 *   - Account
 *   - Transaction (Purchase, JournalEntry, Transfer)
 *   - Invoice
 *   - Payment
 *   - Vendor
 *   - Customer
 *   - Item
 */

import type { QboConnection } from "../../../drizzle/schema";

// ─── Sync result scaffold ─────────────────────────────────────────────────────

export interface SyncResult {
  connectionId: number;
  entitiesSynced: number;
  errors: string[];
  syncedAt: Date;
}

/**
 * Runs a full or incremental sync for a QBO connection.
 * [SCAFFOLD] — Implementation deferred to Phase 2.
 */
export async function syncConnection(
  _connection: QboConnection
): Promise<SyncResult> {
  throw new Error(
    "QBO data sync is not yet implemented (Phase 2). " +
      "Add QBO_CLIENT_ID and QBO_CLIENT_SECRET first, then implement this module."
  );
}
