/**
 * qbo/api.ts
 *
 * QuickBooks Online API client with proper authentication and data fetching.
 *
 * Follows the correct bookkeeping diagnostic order:
 * 1. Profit & Loss statement (revenue/expense structure)
 * 2. Balance Sheet (assets/liabilities/equity)
 * 3. General Ledger detail (account-level balances)
 * 4. Transactions (only after report-level anomalies identified)
 *
 * Token refresh is handled automatically. All API calls require an active
 * QBO connection with valid access token.
 */

import axios, { AxiosInstance } from "axios";
import { getActiveConnection, upsertConnection } from "./index";
import type { QboConnection } from "../../../drizzle/schema";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface QboApiConfig {
  userId: number;
  realmId: string;
  accessToken: string;
  refreshToken: string;
  environment: "sandbox" | "production";
}

export interface ProfitAndLossReport {
  name: string;
  columns: Array<{
    colTitle: string;
    colType: string;
    metaData: Array<{ name: string; value: string }>;
  }>;
  rows: Array<{
    rowIndex: number;
    values: string[];
    summary?: boolean;
    header?: boolean;
    depth?: number;
  }>;
}

export interface BalanceSheetReport {
  name: string;
  columns: Array<{
    colTitle: string;
    colType: string;
    metaData: Array<{ name: string; value: string }>;
  }>;
  rows: Array<{
    rowIndex: number;
    values: string[];
    summary?: boolean;
    header?: boolean;
    depth?: number;
  }>;
}

export interface JournalEntry {
  id: string;
  docNumber: string;
  txnDate: string;
  line: Array<{
    detailType: string;
    amount: number;
    accountRef: { value: string; name: string };
    description?: string;
  }>;
  totalAmt: number;
}

export interface Transaction {
  id: string;
  docNumber: string;
  txnDate: string;
  amount: number;
  accountRef?: { value: string; name: string };
  entityRef?: { value: string; name: string };
  description?: string;
  [key: string]: unknown;
}

export interface Account {
  id: string;
  name: string;
  type: string;
  subType: string;
  currentBalance: number;
  active: boolean;
}

// ─── QBO API Client ───────────────────────────────────────────────────────────

export class QboApiClient {
  private axiosInstance: AxiosInstance;
  private config: QboApiConfig;
  private baseUrl: string;

  constructor(config: QboApiConfig) {
    this.config = config;
    this.baseUrl =
      config.environment === "sandbox"
        ? "https://quickbooks.api.intuit.com"
        : "https://quickbooks.api.intuit.com";

    this.axiosInstance = axios.create({
      baseURL: this.baseUrl,
      headers: {
        Authorization: `Bearer ${config.accessToken}`,
        "Content-Type": "application/json",
      },
    });
  }

  /**
   * Fetches the Profit & Loss report for the company.
   * This is the first diagnostic check — understand revenue/expense structure.
   */
  async getProfitAndLoss(
    startDate: string,
    endDate: string
  ): Promise<ProfitAndLossReport> {
    const query = `select * from ProfitAndLoss where startDate='${startDate}' and endDate='${endDate}'`;
    return this.executeQuery<ProfitAndLossReport>(query);
  }

  /**
   * Fetches the Balance Sheet report for the company.
   * Second diagnostic check — understand asset/liability/equity structure.
   */
  async getBalanceSheet(asOfDate: string): Promise<BalanceSheetReport> {
    const query = `select * from BalanceSheet where asOfDate='${asOfDate}'`;
    return this.executeQuery<BalanceSheetReport>(query);
  }

  /**
   * Fetches all accounts in the company.
   * Used for account-level detail analysis.
   */
  async getAccounts(): Promise<Account[]> {
    const query = `select * from Account where active=true`;
    const response = await this.executeQuery<{ queryResponse: { Account: Account[] } }>(
      query
    );
    return response.queryResponse?.Account || [];
  }

  /**
   * Fetches journal entries (GL detail) for a date range.
   * Third diagnostic check — account-level balances and GL detail.
   */
  async getJournalEntries(startDate: string, endDate: string): Promise<JournalEntry[]> {
    const query = `select * from JournalEntry where txnDate >= '${startDate}' and txnDate <= '${endDate}'`;
    const response = await this.executeQuery<{ queryResponse: { JournalEntry: JournalEntry[] } }>(
      query
    );
    return response.queryResponse?.JournalEntry || [];
  }

  /**
   * Fetches transactions (checks, invoices, bills, etc.) for a date range.
   * Fourth diagnostic check — only after report-level anomalies are identified.
   *
   * Supports filtering by type and account.
   */
  async getTransactions(
    startDate: string,
    endDate: string,
    filters?: {
      type?: string;
      accountId?: string;
    }
  ): Promise<Transaction[]> {
    let query = `select * from Transaction where txnDate >= '${startDate}' and txnDate <= '${endDate}'`;

    if (filters?.type) {
      query += ` and type='${filters.type}'`;
    }

    const response = await this.executeQuery<{ queryResponse: { Transaction: Transaction[] } }>(
      query
    );
    return response.queryResponse?.Transaction || [];
  }

  /**
   * Executes a QBO query using the Query API.
   * Handles authentication and error cases.
   */
  private async executeQuery<T>(query: string): Promise<T> {
    try {
      const response = await this.axiosInstance.post<T>(
        `/v2/company/${this.config.realmId}/query`,
        null,
        {
          params: { query },
        }
      );
      return response.data;
    } catch (error: unknown) {
      if (axios.isAxiosError(error)) {
        if (error.response?.status === 401) {
          throw new Error("QBO authentication failed — token may be expired");
        }
        throw new Error(`QBO API error: ${error.response?.statusText || error.message}`);
      }
      throw error;
    }
  }

  /**
   * Refreshes the access token using the refresh token.
   * Called automatically when token is expired.
   */
  async refreshAccessToken(): Promise<string> {
    // TODO: Implement token refresh using OAuth 2.0 refresh token flow
    // This requires client credentials and should be called from a server-side procedure
    throw new Error("Token refresh not yet implemented");
  }
}

/**
 * Factory function to create a QBO API client from a user's active connection.
 * Returns null if no active connection exists.
 */
export async function createQboApiClient(
  userId: number,
  environment: "sandbox" | "production" = "sandbox"
): Promise<QboApiClient | null> {
  const connection = await getActiveConnection(userId);
  if (!connection || !connection.accessToken) {
    return null;
  }

  return new QboApiClient({
    userId,
    realmId: connection.realmId,
    accessToken: connection.accessToken,
    refreshToken: connection.refreshToken || "",
    environment,
  });
}
