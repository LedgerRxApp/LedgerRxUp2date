/**
 * qbo/oauth.ts
 *
 * QuickBooks Online OAuth 2.0 scaffold.
 *
 * ─── CREDENTIAL GATE ──────────────────────────────────────────────────────────
 * This module reads QBO_CLIENT_ID and QBO_CLIENT_SECRET from environment
 * variables.  Until those values are present, all exported functions will
 * throw a descriptive error rather than silently failing.
 *
 * Required environment variables (see .env.example):
 *   QBO_CLIENT_ID      — from Intuit Developer Portal → App → Keys & OAuth
 *   QBO_CLIENT_SECRET  — from Intuit Developer Portal → App → Keys & OAuth
 *   QBO_REDIRECT_URI   — must match EXACTLY what is registered in Intuit
 *   QBO_ENVIRONMENT    — "sandbox" | "production"
 *
 * ─── REDIRECT URI ─────────────────────────────────────────────────────────────
 * Register the following URI in your Intuit app under
 * "Redirect URIs" (Settings → Your App → Keys & OAuth):
 *
 *   https://<your-domain>/api/qbo/callback
 *
 * For local development:
 *   http://localhost:3000/api/qbo/callback
 *
 * ─── NEXT STEP ────────────────────────────────────────────────────────────────
 * Once credentials are in .env, the areCredentialsConfigured() guard will
 * pass and the full OAuth flow will become operational.
 */

import { nanoid } from "nanoid";

// ─── Intuit OAuth endpoints ───────────────────────────────────────────────────

const INTUIT_AUTHORIZATION_ENDPOINT =
  "https://appcenter.intuit.com/connect/oauth2";
const INTUIT_TOKEN_ENDPOINT =
  "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer";
const INTUIT_REVOKE_ENDPOINT =
  "https://developer.api.intuit.com/v2/oauth2/tokens/revoke";

// ─── Scopes ───────────────────────────────────────────────────────────────────

export const QBO_SCOPES = [
  "com.intuit.quickbooks.accounting",
  "openid",
  "profile",
  "email",
] as const;

// ─── Credential guard ─────────────────────────────────────────────────────────

export interface QboCredentials {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  environment: "sandbox" | "production";
}

/**
 * Returns true when all required QuickBooks credentials are present in the
 * environment.  Use this to gate the connect flow in the UI.
 */
export function areCredentialsConfigured(): boolean {
  return !!(
    process.env.QBO_CLIENT_ID &&
    process.env.QBO_CLIENT_SECRET &&
    process.env.QBO_REDIRECT_URI
  );
}

/**
 * Reads credentials from environment variables.
 * Throws a clear error if any required variable is missing.
 */
export function getCredentials(): QboCredentials {
  const missing: string[] = [];
  if (!process.env.QBO_CLIENT_ID) missing.push("QBO_CLIENT_ID");
  if (!process.env.QBO_CLIENT_SECRET) missing.push("QBO_CLIENT_SECRET");
  if (!process.env.QBO_REDIRECT_URI) missing.push("QBO_REDIRECT_URI");

  if (missing.length > 0) {
    throw new Error(
      `QuickBooks OAuth is not configured. Missing environment variables: ${missing.join(", ")}. ` +
        `Add them to your .env file (see .env.example) and restart the server.`
    );
  }

  return {
    clientId: process.env.QBO_CLIENT_ID!,
    clientSecret: process.env.QBO_CLIENT_SECRET!,
    redirectUri: process.env.QBO_REDIRECT_URI!,
    environment: (process.env.QBO_ENVIRONMENT as "sandbox" | "production") ?? "sandbox",
  };
}

// ─── OAuth URL builder ────────────────────────────────────────────────────────

export interface AuthorizationUrlResult {
  url: string;
  state: string;
}

/**
 * Builds the Intuit authorization URL that the user is redirected to.
 * The `state` parameter is a random nonce stored server-side to prevent CSRF.
 *
 * @throws if credentials are not configured
 */
export function buildAuthorizationUrl(): AuthorizationUrlResult {
  const { clientId, redirectUri } = getCredentials();
  const state = nanoid(32);

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: QBO_SCOPES.join(" "),
    state,
  });

  return {
    url: `${INTUIT_AUTHORIZATION_ENDPOINT}?${params.toString()}`,
    state,
  };
}

// ─── Token exchange scaffold ──────────────────────────────────────────────────

export interface TokenResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
  x_refresh_token_expires_in: number;
  realmId: string;
}

/**
 * Exchanges an authorization code for access + refresh tokens.
 * Called from the /api/qbo/callback route after Intuit redirects back.
 *
 * @throws if credentials are not configured or the exchange fails
 */
export async function exchangeCodeForTokens(
  code: string,
  realmId: string
): Promise<TokenResponse> {
  const { clientId, clientSecret, redirectUri } = getCredentials();

  const body = new URLSearchParams({
    grant_type: "authorization_code",
    code,
    redirect_uri: redirectUri,
  });

  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");

  const response = await fetch(INTUIT_TOKEN_ENDPOINT, {
    method: "POST",
    headers: {
      Authorization: `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
    },
    body: body.toString(),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(
      `QuickBooks token exchange failed (${response.status}): ${text}`
    );
  }

  const data = (await response.json()) as Omit<TokenResponse, "realmId">;
  return { ...data, realmId };
}

/**
 * Refreshes an expired access token using the stored refresh token.
 *
 * @throws if credentials are not configured or the refresh fails
 */
export async function refreshAccessToken(
  refreshToken: string
): Promise<Pick<TokenResponse, "access_token" | "expires_in" | "refresh_token" | "x_refresh_token_expires_in">> {
  const { clientId, clientSecret } = getCredentials();

  const body = new URLSearchParams({
    grant_type: "refresh_token",
    refresh_token: refreshToken,
  });

  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");

  const response = await fetch(INTUIT_TOKEN_ENDPOINT, {
    method: "POST",
    headers: {
      Authorization: `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
    },
    body: body.toString(),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(
      `QuickBooks token refresh failed (${response.status}): ${text}`
    );
  }

  return response.json();
}

/**
 * Revokes a token (access or refresh) at Intuit's revocation endpoint.
 */
export async function revokeToken(token: string): Promise<void> {
  const { clientId, clientSecret } = getCredentials();
  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");

  await fetch(INTUIT_REVOKE_ENDPOINT, {
    method: "POST",
    headers: {
      Authorization: `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
    },
    body: new URLSearchParams({ token }).toString(),
  });
}

export { INTUIT_AUTHORIZATION_ENDPOINT, INTUIT_TOKEN_ENDPOINT };
