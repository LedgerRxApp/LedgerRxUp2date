/**
 * qbo module
 *
 * Database helpers for managing QuickBooks Online connections.
 * OAuth URL building and token exchange live in ./oauth.ts.
 */

import { eq, and } from "drizzle-orm";
import { getDb } from "../../db";
import {
  qboConnections,
  type InsertQboConnection,
  type QboConnection,
} from "../../../drizzle/schema";

// ─── Connection helpers ───────────────────────────────────────────────────────

/**
 * Returns the active QBO connection for a user, or undefined if none exists.
 */
export async function getActiveConnection(
  userId: number
): Promise<QboConnection | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const rows = await db
    .select()
    .from(qboConnections)
    .where(and(eq(qboConnections.userId, userId), eq(qboConnections.isActive, true)))
    .limit(1);

  return rows[0];
}

/**
 * Upserts a QBO connection after a successful OAuth callback.
 * If the user already has a connection for this realmId, it is updated;
 * otherwise a new row is inserted.
 */
export async function upsertConnection(
  data: InsertQboConnection
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Deactivate any existing connections for this user first
  await db
    .update(qboConnections)
    .set({ isActive: false })
    .where(eq(qboConnections.userId, data.userId));

  // Insert the new active connection
  await db.insert(qboConnections).values({
    ...data,
    isActive: true,
  });
}

/**
 * Marks a user's active connection as inactive (disconnect).
 */
export async function deactivateConnection(userId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(qboConnections)
    .set({ isActive: false })
    .where(and(eq(qboConnections.userId, userId), eq(qboConnections.isActive, true)));
}

/**
 * Returns all connections (active and inactive) for a user.
 * Useful for the settings/audit view.
 */
export async function getAllConnections(
  userId: number
): Promise<QboConnection[]> {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(qboConnections)
    .where(eq(qboConnections.userId, userId));
}

export * from "./oauth";
