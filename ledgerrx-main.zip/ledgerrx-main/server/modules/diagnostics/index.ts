/**
 * diagnostics module  [SCAFFOLD — Phase 2]
 *
 * This module will contain the check runners that pull data from the
 * QuickBooks API and evaluate it against diagnostic rules.
 *
 * Planned checks (Phase 2):
 *   - uncategorized_transactions   : Transactions with no category/account
 *   - duplicate_vendors            : Vendor names that appear to be duplicates
 *   - missing_customer_info        : Customers with incomplete contact data
 *   - unreconciled_accounts        : Bank accounts not reconciled in >30 days
 *   - negative_inventory           : Items with negative quantity on hand
 *   - stale_open_invoices          : Invoices open for >90 days
 *   - mismatched_payments          : Payments not matched to invoices
 *
 * Each check will implement the DiagnosticCheck interface below.
 */

import type { QboConnection } from "../../../drizzle/schema";

// ─── Check interface (scaffold) ───────────────────────────────────────────────

export interface DiagnosticCheckResult {
  checkKey: string;
  title: string;
  description: string;
  severity: "critical" | "warning" | "info";
  affectedCount: number;
  metadata?: Record<string, unknown>;
}

export interface DiagnosticCheck {
  key: string;
  title: string;
  description: string;
  /** Run the check against a live QBO connection */
  run(connection: QboConnection): Promise<DiagnosticCheckResult[]>;
}

// ─── Registry (empty — checks registered in Phase 2) ─────────────────────────

export const diagnosticRegistry: DiagnosticCheck[] = [];

/**
 * Runs all registered diagnostic checks for a connection.
 * Returns an empty array until checks are implemented in Phase 2.
 */
export async function runAllChecks(
  _connection: QboConnection
): Promise<DiagnosticCheckResult[]> {
  // Phase 2: iterate diagnosticRegistry and call each check.run()
  return [];
}
