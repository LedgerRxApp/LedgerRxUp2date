/**
 * diagnostics/accountClassifier.ts
 *
 * QBO Account Type/Subtype Classification
 *
 * Maps QBO account types and subtypes to financial statement groups.
 * Uses type/subtype as primary logic, falls back to name matching only as last resort.
 *
 * QBO Account Structure:
 * - type: Asset | Liability | Equity | Income | Expense
 * - subType: Specific classification within type
 *
 * Balance Sheet Groups:
 * - Bank, Accounts Receivable, Other Current Assets, Fixed Assets, Other Assets
 * - Accounts Payable, Credit Card, Other Current Liabilities, Long Term Liabilities
 * - Equity
 *
 * Profit & Loss Groups:
 * - Income, Cost of Goods Sold, Expenses, Other Income, Other Expense
 */

import type { Account } from "../qbo/api";

// ─── Account Type Constants ────────────────────────────────────────────────────

export const ACCOUNT_TYPES = {
  ASSET: "Asset",
  LIABILITY: "Liability",
  EQUITY: "Equity",
  INCOME: "Income",
  EXPENSE: "Expense",
} as const;

export const ASSET_SUBTYPES = {
  CASH: "Cash",
  ACCOUNTS_RECEIVABLE: "AccountsReceivable",
  OTHER_CURRENT_ASSET: "OtherCurrentAsset",
  FIXED_ASSET: "FixedAsset",
  OTHER_ASSET: "OtherAsset",
  UNDEPOSITED_FUNDS: "UndepositedFunds",
  INVENTORY: "Inventory",
  ACCUMULATED_DEPRECIATION: "AccumulatedDepreciation",
} as const;

export const LIABILITY_SUBTYPES = {
  ACCOUNTS_PAYABLE: "AccountsPayable",
  CREDIT_CARD: "CreditCard",
  OTHER_CURRENT_LIABILITY: "OtherCurrentLiability",
  LONG_TERM_LIABILITY: "LongTermLiability",
  SALES_TAX_PAYABLE: "SalesTaxPayable",
} as const;

export const EQUITY_SUBTYPES = {
  EQUITY: "Equity",
  RETAINED_EARNINGS: "RetainedEarnings",
  OPENING_BALANCE: "OpeningBalance",
} as const;

export const INCOME_SUBTYPES = {
  INCOME: "Income",
  OTHER_INCOME: "OtherIncome",
  SALES_OF_PRODUCT_INCOME: "SalesOfProductIncome",
  SALES_OF_SERVICE_INCOME: "SalesOfServiceIncome",
} as const;

export const EXPENSE_SUBTYPES = {
  EXPENSE: "Expense",
  COST_OF_GOODS_SOLD: "CostOfGoodsSold",
  OTHER_EXPENSE: "OtherExpense",
} as const;

// ─── Account Classifier ────────────────────────────────────────────────────────

/**
 * Classifies accounts using QBO type/subtype as primary logic.
 * Falls back to name matching only as last resort.
 */
export class AccountClassifier {
  /**
   * Check if account is a Balance Sheet account (Asset, Liability, Equity)
   */
  static isBalanceSheetAccount(account: Account): boolean {
    return (
      account.type === ACCOUNT_TYPES.ASSET ||
      account.type === ACCOUNT_TYPES.LIABILITY ||
      account.type === ACCOUNT_TYPES.EQUITY
    );
  }

  /**
   * Check if account is a P&L account (Income, Expense)
   */
  static isPnlAccount(account: Account): boolean {
    return (
      account.type === ACCOUNT_TYPES.INCOME ||
      account.type === ACCOUNT_TYPES.EXPENSE
    );
  }

  // ─── Asset Classification ─────────────────────────────────────────────────────

  static isAsset(account: Account): boolean {
    return account.type === ACCOUNT_TYPES.ASSET;
  }

  static isCash(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.ASSET) return false;
    // Primary: use subtype
    if (account.subType === ASSET_SUBTYPES.CASH) return true;
    // Fallback: name matching
    const name = account.name.toLowerCase();
    return (
      name.includes("cash") ||
      name.includes("bank") ||
      name.includes("checking") ||
      name.includes("savings")
    );
  }

  static isAccountsReceivable(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.ASSET) return false;
    // Primary: use subtype
    if (account.subType === ASSET_SUBTYPES.ACCOUNTS_RECEIVABLE) return true;
    // Fallback: name matching
    return account.name.toLowerCase().includes("receivable");
  }

  static isUndepositedFunds(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.ASSET) return false;
    // Primary: use subtype
    if (account.subType === ASSET_SUBTYPES.UNDEPOSITED_FUNDS) return true;
    // Fallback: name matching
    const name = account.name.toLowerCase();
    return (
      name.includes("undeposited") ||
      name.includes("customer payments") ||
      name.includes("undeposited funds")
    );
  }

  static isInventory(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.ASSET) return false;
    // Primary: use subtype
    if (account.subType === ASSET_SUBTYPES.INVENTORY) return true;
    // Fallback: name matching
    return account.name.toLowerCase().includes("inventory");
  }

  static isFixedAsset(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.ASSET) return false;
    // Primary: use subtype
    if (
      account.subType === ASSET_SUBTYPES.FIXED_ASSET ||
      account.subType === ASSET_SUBTYPES.ACCUMULATED_DEPRECIATION
    )
      return true;
    // Fallback: name matching
    const name = account.name.toLowerCase();
    return (
      name.includes("property") ||
      name.includes("equipment") ||
      name.includes("fixed") ||
      name.includes("depreciation")
    );
  }

  static isOtherCurrentAsset(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.ASSET) return false;
    return account.subType === ASSET_SUBTYPES.OTHER_CURRENT_ASSET;
  }

  static isOtherAsset(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.ASSET) return false;
    return account.subType === ASSET_SUBTYPES.OTHER_ASSET;
  }

  // ─── Liability Classification ─────────────────────────────────────────────────

  static isLiability(account: Account): boolean {
    return account.type === ACCOUNT_TYPES.LIABILITY;
  }

  static isAccountsPayable(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.LIABILITY) return false;
    // Primary: use subtype
    if (account.subType === LIABILITY_SUBTYPES.ACCOUNTS_PAYABLE) return true;
    // Fallback: name matching
    return account.name.toLowerCase().includes("payable");
  }

  static isCreditCard(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.LIABILITY) return false;
    // Primary: use subtype
    if (account.subType === LIABILITY_SUBTYPES.CREDIT_CARD) return true;
    // Fallback: name matching
    return account.name.toLowerCase().includes("credit card");
  }

  static isOtherCurrentLiability(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.LIABILITY) return false;
    return account.subType === LIABILITY_SUBTYPES.OTHER_CURRENT_LIABILITY;
  }

  static isLongTermLiability(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.LIABILITY) return false;
    return account.subType === LIABILITY_SUBTYPES.LONG_TERM_LIABILITY;
  }

  static isSalesTaxPayable(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.LIABILITY) return false;
    // Primary: use subtype
    if (account.subType === LIABILITY_SUBTYPES.SALES_TAX_PAYABLE) return true;
    // Fallback: name matching
    const name = account.name.toLowerCase();
    return name.includes("sales tax") || name.includes("tax payable");
  }

  // ─── Equity Classification ────────────────────────────────────────────────────

  static isEquity(account: Account): boolean {
    return account.type === ACCOUNT_TYPES.EQUITY;
  }

  static isRetainedEarnings(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.EQUITY) return false;
    // Primary: use subtype
    if (account.subType === EQUITY_SUBTYPES.RETAINED_EARNINGS) return true;
    // Fallback: name matching
    return account.name.toLowerCase().includes("retained earnings");
  }

  // ─── Income Classification ────────────────────────────────────────────────────

  static isIncome(account: Account): boolean {
    return account.type === ACCOUNT_TYPES.INCOME;
  }

  static isOtherIncome(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.INCOME) return false;
    return account.subType === INCOME_SUBTYPES.OTHER_INCOME;
  }

  // ─── Expense Classification ───────────────────────────────────────────────────

  static isExpense(account: Account): boolean {
    return account.type === ACCOUNT_TYPES.EXPENSE;
  }

  static isCostOfGoodsSold(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.EXPENSE) return false;
    return account.subType === EXPENSE_SUBTYPES.COST_OF_GOODS_SOLD;
  }

  static isOtherExpense(account: Account): boolean {
    if (account.type !== ACCOUNT_TYPES.EXPENSE) return false;
    return account.subType === EXPENSE_SUBTYPES.OTHER_EXPENSE;
  }

  // ─── Special Account Detection ─────────────────────────────────────────────────

  /**
   * Detect suspense/ask my accountant accounts
   * These are typically named "Suspense" or "Ask My Accountant"
   * QBO doesn't have a specific type for these, so name matching is primary
   */
  static isSuspense(account: Account): boolean {
    const name = account.name.toLowerCase();
    return (
      name.includes("suspense") ||
      name.includes("ask my accountant") ||
      name.includes("clearing")
    );
  }

  /**
   * Get account classification group (for Balance Sheet)
   */
  static getBsGroup(
    account: Account
  ): "Bank" | "AR" | "OCA" | "FA" | "OA" | "AP" | "CC" | "OCL" | "LTL" | "Equity" | null {
    if (!this.isBalanceSheetAccount(account)) return null;

    if (this.isCash(account)) return "Bank";
    if (this.isAccountsReceivable(account)) return "AR";
    if (this.isOtherCurrentAsset(account)) return "OCA";
    if (this.isFixedAsset(account)) return "FA";
    if (this.isOtherAsset(account)) return "OA";
    if (this.isAccountsPayable(account)) return "AP";
    if (this.isCreditCard(account)) return "CC";
    if (this.isOtherCurrentLiability(account)) return "OCL";
    if (this.isLongTermLiability(account)) return "LTL";
    if (this.isEquity(account)) return "Equity";

    return null;
  }

  /**
   * Get account classification group (for P&L)
   */
  static getPnlGroup(
    account: Account
  ): "Income" | "COGS" | "Expense" | "OI" | "OE" | null {
    if (!this.isPnlAccount(account)) return null;

    if (this.isCostOfGoodsSold(account)) return "COGS";
    if (this.isOtherIncome(account)) return "OI";
    if (this.isOtherExpense(account)) return "OE";
    if (account.type === ACCOUNT_TYPES.INCOME) return "Income";
    if (account.type === ACCOUNT_TYPES.EXPENSE) return "Expense";

    return null;
  }
}

// ─── Materiality Constants ────────────────────────────────────────────────────

export const MATERIALITY = {
  ABSOLUTE_MINIMUM: 100, // $100 minimum for any finding
  PERCENT_OF_TOTAL: 0.001, // 0.1% minimum
  CONCENTRATION_THRESHOLD: 0.6, // 60% concentration for revenue
  EXPENSE_CONCENTRATION_THRESHOLD: 0.5, // 50% concentration for expenses
  UNDEPOSITED_FUNDS_THRESHOLD: 10000, // $10,000 for undeposited funds
} as const;

/**
 * Check if an amount is material (significant enough to flag)
 */
export function isMaterial(amount: number, totalAmount?: number): boolean {
  const absoluteAmount = Math.abs(amount);

  // Fail if below absolute minimum
  if (absoluteAmount < MATERIALITY.ABSOLUTE_MINIMUM) {
    return false;
  }

  // If total provided, also check percentage
  if (totalAmount && totalAmount > 0) {
    const percentage = absoluteAmount / Math.abs(totalAmount);
    if (percentage < MATERIALITY.PERCENT_OF_TOTAL) {
      return false;
    }
  }

  return true;
}

/**
 * Check if concentration is material
 */
export function isConcentrationMaterial(
  dominantAmount: number,
  totalAmount: number,
  threshold: number = MATERIALITY.CONCENTRATION_THRESHOLD
): boolean {
  if (totalAmount === 0) return false;

  const concentration = Math.abs(dominantAmount) / Math.abs(totalAmount);
  return (
    concentration > threshold &&
    isMaterial(dominantAmount, totalAmount)
  );
}
