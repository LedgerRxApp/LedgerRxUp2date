/**
 * diagnostics/refinements.ts
 *
 * Targeted refinement improvements for Phase 2:
 * 1. Materiality awareness (skip insignificant findings)
 * 2. Account type/subtype detection (reduce string matching)
 * 3. Smart transaction drilldown (only when needed)
 * 4. Improved findings quality (financial impact metrics)
 *
 * These refinements are applied to the existing DiagnosticEngine
 * without breaking changes to the core architecture.
 */

import type { Account } from "../qbo/api";

// ─── Materiality Constants ─────────────────────────────────────────────────────

export const MATERIALITY = {
  ABSOLUTE_MINIMUM: 100, // $100 minimum for any finding
  PERCENT_OF_TOTAL: 0.001, // 0.1% minimum
  CONCENTRATION_THRESHOLD: 0.6, // 60% concentration for revenue
  EXPENSE_CONCENTRATION_THRESHOLD: 0.5, // 50% concentration for expenses
  UNDEPOSITED_FUNDS_THRESHOLD: 10000, // $10,000 for undeposited funds
};

// ─── Account Type Detection ───────────────────────────────────────────────────

/**
 * Reliable account classification using QBO type/subtype.
 * Avoids string matching by using official QBO account classifications.
 */
export class AccountClassifier {
  /**
   * QBO Account Types:
   * - Asset: Cash, AccountsReceivable, OtherCurrentAsset, FixedAsset, OtherAsset
   * - Liability: AccountsPayable, CreditCard, OtherCurrentLiability, LongTermLiability
   * - Equity: Equity, RetainedEarnings, OtherCurrentLiability
   * - Income: Income, OtherIncome
   * - Expense: Expense, OtherExpense, CostOfGoodsSold
   */

  static isAsset(account: Account): boolean {
    return account.type === "Asset";
  }

  static isLiability(account: Account): boolean {
    return account.type === "Liability";
  }

  static isEquity(account: Account): boolean {
    return account.type === "Equity";
  }

  static isIncome(account: Account): boolean {
    return account.type === "Income";
  }

  static isExpense(account: Account): boolean {
    return account.type === "Expense";
  }

  static isCash(account: Account): boolean {
    return account.type === "Asset" && account.subType === "Cash";
  }

  static isAccountsReceivable(account: Account): boolean {
    return account.type === "Asset" && account.subType === "AccountsReceivable";
  }

  static isAccountsPayable(account: Account): boolean {
    return account.type === "Liability" && account.subType === "AccountsPayable";
  }

  static isSuspense(account: Account): boolean {
    // Suspense accounts are typically named "Suspense" or "Ask My Accountant"
    const name = account.name.toLowerCase();
    return name.includes("suspense") || name.includes("ask my accountant");
  }

  static isUndepositedFunds(account: Account): boolean {
    const name = account.name.toLowerCase();
    return name.includes("undeposited") || name.includes("customer payments");
  }
}

// ─── Materiality Checks ────────────────────────────────────────────────────────

/**
 * Check if an amount is material (significant enough to flag).
 * Uses absolute minimum and percentage thresholds.
 */
export function isMaterial(amount: number, totalAmount?: number): boolean {
  const absoluteAmount = Math.abs(amount);

  // Fail if below absolute minimum
  if (absoluteAmount < MATERIALITY.ABSOLUTE_MINIMUM) {
    return false;
  }

  // If total provided, also check percentage
  if (totalAmount && totalAmount > 0) {
    const percentage = absoluteAmount / totalAmount;
    if (percentage < MATERIALITY.PERCENT_OF_TOTAL) {
      return false;
    }
  }

  return true;
}

/**
 * Check if concentration is material.
 * Used for revenue/expense concentration checks.
 */
export function isConcentrationMaterial(
  dominantAmount: number,
  totalAmount: number,
  threshold: number = MATERIALITY.CONCENTRATION_THRESHOLD
): boolean {
  if (totalAmount === 0) return false;

  const concentration = Math.abs(dominantAmount) / Math.abs(totalAmount);
  return concentration > threshold && isMaterial(dominantAmount, totalAmount);
}

// ─── Transaction Drilldown Triggers ────────────────────────────────────────────

/**
 * Determines whether transaction-level checks should run.
 * Only drills into transactions when specific report-level anomalies are found.
 */
export class DrilldownTrigger {
  private triggers: Set<string> = new Set();

  /**
   * Add a trigger for transaction drilldown.
   * Triggers indicate that a specific report-level anomaly requires transaction analysis.
   */
  add(reason: string): void {
    this.triggers.add(reason);
  }

  /**
   * Check if any drilldown triggers are active.
   * If false, skip transaction-level checks entirely.
   */
  shouldDrilldown(): boolean {
    return this.triggers.size > 0;
  }

  /**
   * Get all active triggers (for logging/debugging).
   */
  getActiveTriggers(): string[] {
    return Array.from(this.triggers);
  }

  /**
   * Reset triggers for next healthcheck run.
   */
  reset(): void {
    this.triggers.clear();
  }
}

// ─── Financial Impact Metrics ──────────────────────────────────────────────────

/**
 * Structured financial impact information for findings.
 * Helps users understand the magnitude and location of issues.
 */
export interface FinancialImpact {
  amount?: number; // Dollar amount of the issue
  percentOfTotal?: number; // Percentage of total (0-1)
  reportLine?: string; // Which report line is affected (e.g., "Total Assets")
  accounts?: string[]; // Specific accounts involved
}

/**
 * Create financial impact metrics for a finding.
 */
export function createFinancialImpact(
  amount: number,
  totalAmount: number,
  reportLine: string,
  accounts?: string[]
): FinancialImpact {
  return {
    amount: Math.abs(amount),
    percentOfTotal: totalAmount > 0 ? Math.abs(amount) / Math.abs(totalAmount) : 0,
    reportLine,
    accounts,
  };
}

// ─── Evidence Linking ──────────────────────────────────────────────────────────

/**
 * Helper to create evidence summaries that clearly link to source data.
 * Evidence should explain the financial impact, not just describe the pattern.
 */
export class EvidenceBuilder {
  static abnormalBalance(accountName: string, balance: number, expectedSign: "positive" | "negative"): string {
    const sign = balance < 0 ? "negative" : "positive";
    const expected = expectedSign === "positive" ? "positive" : "negative";
    return `${accountName} has a ${sign} balance of ${Math.abs(balance).toFixed(2)}, but ${expected} balances are expected. This affects the Balance Sheet total.`;
  }

  static concentration(dominantAccount: string, amount: number, percentage: number, total: number, type: "revenue" | "expense"): string {
    return `${dominantAccount} accounts for ${(percentage * 100).toFixed(1)}% of total ${type} (${amount.toFixed(2)} of ${total.toFixed(2)}). This concentration creates business risk and may indicate miscoding.`;
  }

  static suspenseUsage(accountName: string, balance: number): string {
    return `${accountName} has a balance of ${Math.abs(balance).toFixed(2)}. Suspense accounts should be temporary and cleared regularly. This balance distorts both P&L and Balance Sheet.`;
  }

  static uncategorizedTransactions(count: number, totalAmount: number): string {
    return `${count} transactions totaling ${totalAmount.toFixed(2)} are uncategorized or in undeposited funds. This amount distorts financial reports and should be categorized.`;
  }

  static duplicateTransactions(count: number, totalAmount: number): string {
    return `${count} potential duplicate transactions detected, totaling ${totalAmount.toFixed(2)} in duplicated amounts. Duplicates inflate expenses and distort reports.`;
  }

  static miscategorization(count: number, totalAmount: number): string {
    return `${count} transactions show description-to-account mismatches, totaling ${totalAmount.toFixed(2)}. Miscategorized transactions distort expense analysis and P&L.`;
  }
}
