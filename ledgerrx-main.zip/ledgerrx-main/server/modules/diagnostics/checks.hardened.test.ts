/**
 * diagnostics/checks.hardened.test.ts
 *
 * Tests for HardenedDiagnosticEngine with QBO type/subtype classification,
 * materiality filtering, and narrowed transaction drilldown.
 */

import { describe, it, expect, beforeEach } from "vitest";
import { HardenedDiagnosticEngine } from "./checks";
import { AccountClassifier, isMaterial, isConcentrationMaterial } from "./accountClassifier";
import type { QboApiClient, Account, Transaction } from "../qbo/api";

// ─── Mock QBO API Client ──────────────────────────────────────────────────────

class MockQboApiClient implements QboApiClient {
  async getProfitAndLoss() {
    return {
      name: "Profit and Loss",
      columns: [],
      rows: [
        { rowIndex: 0, values: ["Sales", "100000"] },
        { rowIndex: 1, values: ["Expenses", "-50000"] },
      ],
    };
  }

  async getBalanceSheet() {
    return {
      name: "Balance Sheet",
      columns: [],
      rows: [
        { rowIndex: 0, values: ["Cash", "25000"] },
        { rowIndex: 1, values: ["Accounts Receivable", "15000"] },
        { rowIndex: 2, values: ["Accounts Payable", "-10000"] },
      ],
    };
  }

  async getAccounts(): Promise<Account[]> {
    return [
      {
        id: "1",
        name: "Sales",
        type: "Income",
        subType: "Income",
        currentBalance: 100000,
        active: true,
      },
      {
        id: "2",
        name: "Expenses",
        type: "Expense",
        subType: "Expense",
        currentBalance: -50000,
        active: true,
      },
      {
        id: "3",
        name: "Cash",
        type: "Asset",
        subType: "Cash",
        currentBalance: 25000,
        active: true,
      },
      {
        id: "4",
        name: "Accounts Receivable",
        type: "Asset",
        subType: "AccountsReceivable",
        currentBalance: 15000,
        active: true,
      },
      {
        id: "5",
        name: "Accounts Payable",
        type: "Liability",
        subType: "AccountsPayable",
        currentBalance: -10000,
        active: true,
      },
    ];
  }

  async getJournalEntries() {
    return [];
  }

  async getTransactions(): Promise<Transaction[]> {
    return [];
  }
}

// ─── Account Classifier Tests ─────────────────────────────────────────────────

describe("AccountClassifier", () => {
  it("should classify Cash account using type/subtype", () => {
    const account: Account = {
      id: "1",
      name: "Checking Account",
      type: "Asset",
      subType: "Cash",
      currentBalance: 5000,
      active: true,
    };

    expect(AccountClassifier.isCash(account)).toBe(true);
    expect(AccountClassifier.isAccountsReceivable(account)).toBe(false);
  });

  it("should classify Accounts Receivable using type/subtype", () => {
    const account: Account = {
      id: "2",
      name: "Customer Invoices",
      type: "Asset",
      subType: "AccountsReceivable",
      currentBalance: 12000,
      active: true,
    };

    expect(AccountClassifier.isAccountsReceivable(account)).toBe(true);
    expect(AccountClassifier.isCash(account)).toBe(false);
  });

  it("should classify Accounts Payable using type/subtype", () => {
    const account: Account = {
      id: "3",
      name: "Vendor Bills",
      type: "Liability",
      subType: "AccountsPayable",
      currentBalance: -8000,
      active: true,
    };

    expect(AccountClassifier.isAccountsPayable(account)).toBe(true);
    expect(AccountClassifier.isLiability(account)).toBe(true);
  });

  it("should detect Suspense account by name", () => {
    const account: Account = {
      id: "4",
      name: "Suspense",
      type: "Asset",
      subType: "OtherAsset",
      currentBalance: 500,
      active: true,
    };

    expect(AccountClassifier.isSuspense(account)).toBe(true);
  });

  it("should fallback to name matching when type/subtype not available", () => {
    const account: Account = {
      id: "5",
      name: "My Cash Account",
      type: "Asset",
      subType: "OtherAsset",
      currentBalance: 3000,
      active: true,
    };

    // Should match on name even though subtype is OtherAsset
    expect(AccountClassifier.isCash(account)).toBe(true);
  });
});

// ─── Materiality Tests ────────────────────────────────────────────────────────

describe("Materiality", () => {
  it("should flag amounts above absolute minimum", () => {
    expect(isMaterial(150)).toBe(true);
    expect(isMaterial(99)).toBe(false);
    expect(isMaterial(-150)).toBe(true);
  });

  it("should check percentage of total", () => {
    expect(isMaterial(100, 100000)).toBe(true); // 0.1% of 100,000
    expect(isMaterial(50, 100000)).toBe(false); // 0.05% of 100,000
  });

  it("should flag concentration above threshold", () => {
    expect(isConcentrationMaterial(81000, 100000, 0.8)).toBe(true); // 81% of 100,000 (above 80%)
    expect(isConcentrationMaterial(70000, 100000, 0.8)).toBe(false); // 70% of 100,000 (below 80%)
  });
});

// ─── Hardened Diagnostic Engine Tests ─────────────────────────────────────────

describe("HardenedDiagnosticEngine", () => {
  let engine: HardenedDiagnosticEngine;
  let mockClient: MockQboApiClient;

  beforeEach(() => {
    mockClient = new MockQboApiClient();
    engine = new HardenedDiagnosticEngine(mockClient);
  });

  it("should run diagnostics without errors", async () => {
    const findings = await engine.runDiagnostics("2024-01-01", "2024-12-31", "2024-12-31");
    expect(Array.isArray(findings)).toBe(true);
  });

  it("should use QBO account types for classification", async () => {
    // Verify that the engine uses AccountClassifier methods
    const account: Account = {
      id: "1",
      name: "Cash",
      type: "Asset",
      subType: "Cash",
      currentBalance: 5000,
      active: true,
    };

    expect(AccountClassifier.isCash(account)).toBe(true);
    expect(AccountClassifier.isBalanceSheetAccount(account)).toBe(true);
  });

  it("should filter findings below materiality threshold", async () => {
    // Small amounts should not generate findings
    const smallAmount = 50; // Below $100 minimum
    expect(isMaterial(smallAmount)).toBe(false);
  });

  it("should only drilldown to transactions if report-level anomalies found", async () => {
    // The engine should track drilldown triggers
    // If no P&L/BS anomalies, transaction checks should not run
    const findings = await engine.runDiagnostics("2024-01-01", "2024-12-31", "2024-12-31");

    // With normal data, should not generate transaction-level findings
    // (unless there are actual anomalies)
    expect(Array.isArray(findings)).toBe(true);
  });

  it("should include financial impact in findings", async () => {
    const findings = await engine.runDiagnostics("2024-01-01", "2024-12-31", "2024-12-31");

    // Findings should have financialImpact when relevant
    const findingsWithImpact = findings.filter((f) => f.financialImpact);
    if (findingsWithImpact.length > 0) {
      const finding = findingsWithImpact[0];
      expect(finding.financialImpact).toBeDefined();
      expect(
        finding.financialImpact?.amount !== undefined ||
          finding.financialImpact?.percentOfTotal !== undefined
      ).toBe(true);
    }
  });

  it("should maintain diagnostic order: P&L → BS → GL → Transactions", async () => {
    const findings = await engine.runDiagnostics("2024-01-01", "2024-12-31", "2024-12-31");

    // Verify that findings are generated in the correct order
    // P&L findings should come before transaction findings
    const pnlFindings = findings.filter((f) => f.impactedReports.includes("Profit & Loss"));
    const bsFindings = findings.filter((f) => f.impactedReports.includes("Balance Sheet"));
    const txnFindings = findings.filter((f) => f.title.includes("Transaction"));

    // If transaction findings exist, P&L/BS findings should have been checked first
    if (txnFindings.length > 0) {
      expect(pnlFindings.length + bsFindings.length > 0).toBe(true);
    }
  });

  it("should use conservative transfer logic", async () => {
    // Transfer detection should require matching amounts AND compatible account types
    // Not just matching amounts alone
    const findings = await engine.runDiagnostics("2024-01-01", "2024-12-31", "2024-12-31");

    const transferFindings = findings.filter((f) => f.title.includes("Transfer"));
    for (const finding of transferFindings) {
      // Transfer findings should have low confidence (conservative)
      expect(finding.confidence).toBe("low");
    }
  });
});

// ─── Integration Tests ────────────────────────────────────────────────────────

describe("HardenedDiagnosticEngine Integration", () => {
  it("should handle empty data gracefully", async () => {
    const mockClient = new MockQboApiClient();
    const engine = new HardenedDiagnosticEngine(mockClient);

    const findings = await engine.runDiagnostics("2024-01-01", "2024-12-31", "2024-12-31");
    expect(Array.isArray(findings)).toBe(true);
    expect(findings.length >= 0).toBe(true);
  });

  it("should not generate excessive findings for normal data", async () => {
    const mockClient = new MockQboApiClient();
    const engine = new HardenedDiagnosticEngine(mockClient);

    const findings = await engine.runDiagnostics("2024-01-01", "2024-12-31", "2024-12-31");

    // With normal data, should have minimal findings
    // Findings should be reasonable in count (not excessive false positives)
    expect(findings.length <= 10).toBe(true);
  });

  it("should provide clear evidence and recommendations", async () => {
    const mockClient = new MockQboApiClient();
    const engine = new HardenedDiagnosticEngine(mockClient);

    const findings = await engine.runDiagnostics("2024-01-01", "2024-12-31", "2024-12-31");

    for (const finding of findings) {
      // Every finding should have clear evidence and action
      expect(finding.evidenceSummary).toBeDefined();
      expect(finding.evidenceSummary.length > 0).toBe(true);
      expect(finding.recommendedAction).toBeDefined();
      expect(finding.recommendedAction.length > 0).toBe(true);
    }
  });
});
