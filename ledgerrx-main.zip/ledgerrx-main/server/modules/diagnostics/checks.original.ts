/**
 * diagnostics/checks.ts
 *
 * Diagnostic checks following proper bookkeeping order:
 * 1. P&L analysis (revenue/expense structure)
 * 2. Balance Sheet analysis (asset/liability/equity structure)
 * 3. GL detail (account-level balances vs. P&L/BS)
 * 4. Transactions (only after report-level anomalies identified)
 *
 * Each check returns a Finding with:
 * - title: human-readable issue name
 * - severity: critical | high | medium | low
 * - whyItMatters: business impact explanation
 * - impactedReports: which financial statements are affected
 * - impactedAccounts: which accounts are involved
 * - evidenceSummary: what data supports this finding
 * - confidence: high | medium | low
 * - recommendedAction: what to do next
 * - suitableForGuidedCorrection: can this be auto-fixed?
 *
 * Conservative logic:
 * - Do not aggressively classify items as transfers
 * - Matching amounts alone are not enough for transfer classification
 * - Only identify likely transfers when account movement AND balance sheet behavior support it
 * - If uncertain, lower confidence and flag for review
 */

import type { QboApiClient, ProfitAndLossReport, BalanceSheetReport, JournalEntry, Transaction, Account } from "../qbo/api";

// ─── Finding Type ─────────────────────────────────────────────────────────────

export interface DiagnosticFinding {
  title: string;
  severity: "critical" | "high" | "medium" | "low";
  whyItMatters: string;
  impactedReports: string[];
  impactedAccounts: string[];
  evidenceSummary: string;
  confidence: "high" | "medium" | "low";
  recommendedAction: string;
  suitableForGuidedCorrection: boolean;
  metadata?: Record<string, unknown>;
}

// ─── Diagnostic Pipeline ──────────────────────────────────────────────────────

export class DiagnosticEngine {
  private client: QboApiClient;
  private findings: DiagnosticFinding[] = [];

  constructor(client: QboApiClient) {
    this.client = client;
  }

  /**
   * Runs the complete diagnostic pipeline in the correct order.
   * Returns all findings grouped by severity.
   */
  async runDiagnostics(
    startDate: string,
    endDate: string,
    asOfDate: string
  ): Promise<DiagnosticFinding[]> {
    this.findings = [];

    // Step 1: Fetch financial reports
    const pnl = await this.client.getProfitAndLoss(startDate, endDate);
    const bs = await this.client.getBalanceSheet(asOfDate);
    const accounts = await this.client.getAccounts();
    const journalEntries = await this.client.getJournalEntries(startDate, endDate);

    // Step 2: Analyze P&L structure
    await this.checkPnlStructure(pnl);

    // Step 3: Analyze Balance Sheet structure
    await this.checkBalanceSheetStructure(bs);

    // Step 4: Analyze GL detail and account balances
    await this.checkAccountBalances(accounts, journalEntries, bs);

    // Step 5: Analyze transactions (only after report-level anomalies identified)
    if (this.findings.length > 0) {
      const transactions = await this.client.getTransactions(startDate, endDate);
      await this.checkTransactionLevelIssues(transactions, journalEntries, accounts);
    }

    return this.findings;
  }

  // ─── Step 1: P&L Analysis ─────────────────────────────────────────────────────

  private async checkPnlStructure(pnl: ProfitAndLossReport): Promise<void> {
    if (!pnl.rows || pnl.rows.length === 0) return;

    // Parse P&L rows to extract revenue, expense, and net income data
    const revenueRows: Array<{ name: string; amount: number }> = [];
    const expenseRows: Array<{ name: string; amount: number }> = [];
    let totalRevenue = 0;
    let totalExpenses = 0;
    let netIncome = 0;

    for (const row of pnl.rows) {
      if (!row.values || row.values.length < 2) continue;

      const name = row.values[0] || "";
      const amountStr = row.values[1] || "0";
      const amount = parseFloat(amountStr.replace(/[^0-9.-]/g, "")) || 0;

      // Identify revenue rows (typically contain "Income", "Sales", "Revenue")
      if (
        name.toLowerCase().includes("income") ||
        name.toLowerCase().includes("sales") ||
        name.toLowerCase().includes("revenue")
      ) {
        revenueRows.push({ name, amount });
        totalRevenue += amount;
      }

      // Identify expense rows (typically contain "Expense", "Cost", "Depreciation")
      if (
        name.toLowerCase().includes("expense") ||
        name.toLowerCase().includes("cost") ||
        name.toLowerCase().includes("depreciation") ||
        name.toLowerCase().includes("interest")
      ) {
        expenseRows.push({ name, amount });
        totalExpenses += Math.abs(amount);
      }

      // Track net income (usually last row)
      if (name.toLowerCase().includes("net") && name.toLowerCase().includes("income")) {
        netIncome = amount;
      }
    }

    // Check 1: Unusual income/expense patterns
    await this.checkUnusualPnlPatterns(revenueRows, expenseRows, totalRevenue, totalExpenses);

    // Check 2: Suspicious sign/balance behavior
    await this.checkSuspiciousPnlSigns(revenueRows, expenseRows, netIncome);

    // Check 3: Unexpected concentration or distortion
    await this.checkPnlConcentration(revenueRows, expenseRows, totalRevenue, totalExpenses);
  }

  /**
   * Check for unusual income/expense category patterns.
   * Detects missing categories, unexpected relationships, or structural issues.
   */
  private async checkUnusualPnlPatterns(
    revenueRows: Array<{ name: string; amount: number }>,
    expenseRows: Array<{ name: string; amount: number }>,
    totalRevenue: number,
    totalExpenses: number
  ): Promise<void> {
    // Flag if revenue categories are missing or minimal
    if (revenueRows.length === 0 && totalRevenue === 0) {
      this.findings.push({
        title: "Missing Revenue Categories",
        severity: "high",
        whyItMatters:
          "No revenue categories detected in P&L. This may indicate missing accounts, data entry issues, or a non-revenue business.",
        impactedReports: ["Profit & Loss"],
        impactedAccounts: ["Income"],
        evidenceSummary: "P&L shows no revenue line items.",
        confidence: "medium",
        recommendedAction:
          "Verify that revenue accounts are properly configured and have transactions recorded.",
        suitableForGuidedCorrection: false,
        metadata: {
          totalRevenue,
          revenueCategories: revenueRows.length,
        },
      });
    }

    // Flag if expense categories are missing
    if (expenseRows.length === 0 && totalExpenses > 0) {
      this.findings.push({
        title: "Unusual Expense Structure",
        severity: "medium",
        whyItMatters:
          "Expenses are recorded but no expense categories are visible. This may indicate miscoded transactions or data structure issues.",
        impactedReports: ["Profit & Loss"],
        impactedAccounts: ["Expenses"],
        evidenceSummary: `Total expenses of ${totalExpenses.toFixed(2)} detected but no expense categories identified.`,
        confidence: "medium",
        recommendedAction:
          "Review expense accounts to ensure transactions are properly categorized.",
        suitableForGuidedCorrection: false,
        metadata: {
          totalExpenses,
          expenseCategories: expenseRows.length,
        },
      });
    }
  }

  /**
   * Check for suspicious sign/balance behavior in P&L.
   * Detects reversed signs, negative revenue, or unusual patterns.
   */
  private async checkSuspiciousPnlSigns(
    revenueRows: Array<{ name: string; amount: number }>,
    expenseRows: Array<{ name: string; amount: number }>,
    netIncome: number
  ): Promise<void> {
    const suspiciousRows: Array<{ name: string; amount: number; expectedSign: string }> = [];

    // Revenue should be positive
    for (const row of revenueRows) {
      if (row.amount < 0) {
        suspiciousRows.push({ ...row, expectedSign: "positive" });
      }
    }

    // Expenses should be negative (or positive in absolute terms)
    for (const row of expenseRows) {
      if (row.amount > 0) {
        // In some P&L formats, expenses are shown as positive
        // But if they're mixed with negative revenue, it's suspicious
        if (revenueRows.some((r) => r.amount < 0)) {
          suspiciousRows.push({ ...row, expectedSign: "negative or zero" });
        }
      }
    }

    if (suspiciousRows.length > 0) {
      this.findings.push({
        title: "Suspicious P&L Sign Behavior",
        severity: "high",
        whyItMatters:
          "P&L shows reversed or unexpected signs for income/expense items. This indicates data entry errors or miscoded transactions.",
        impactedReports: ["Profit & Loss"],
        impactedAccounts: suspiciousRows.map((r) => r.name),
        evidenceSummary: `${suspiciousRows.length} line items have unexpected signs: ${suspiciousRows
          .slice(0, 3)
          .map((r) => `${r.name} (${r.amount})`)
          .join(", ")}${suspiciousRows.length > 3 ? "..." : ""}`,
        confidence: "high",
        recommendedAction:
          "Review flagged P&L items and correct any reversed or miscoded transactions.",
        suitableForGuidedCorrection: false,
        metadata: {
          suspiciousItemCount: suspiciousRows.length,
          items: suspiciousRows.map((r) => ({ name: r.name, amount: r.amount })),
        },
      });
    }
  }

  /**
   * Check for unexpected concentration or distortion in P&L.
   * Detects when one category dominates or suggests miscoding.
   */
  private async checkPnlConcentration(
    revenueRows: Array<{ name: string; amount: number }>,
    expenseRows: Array<{ name: string; amount: number }>,
    totalRevenue: number,
    totalExpenses: number
  ): Promise<void> {
    // Check for revenue concentration: if one category is >80% of total
    if (revenueRows.length > 1 && totalRevenue > 0) {
      const maxRevenue = Math.max(...revenueRows.map((r) => Math.abs(r.amount)));
      const concentrationRatio = maxRevenue / totalRevenue;

      if (concentrationRatio > 0.8) {
        const dominantCategory = revenueRows.find(
          (r) => Math.abs(r.amount) === maxRevenue
        );
        this.findings.push({
          title: "Revenue Concentration",
          severity: "medium",
          whyItMatters:
            "Revenue is heavily concentrated in one category. While this may be normal for some businesses, it can indicate miscoding or missing revenue streams.",
          impactedReports: ["Profit & Loss"],
          impactedAccounts: [dominantCategory?.name || "Unknown"],
          evidenceSummary: `${(concentrationRatio * 100).toFixed(1)}% of revenue comes from ${dominantCategory?.name}. Total revenue: ${totalRevenue.toFixed(2)}.`,
          confidence: "medium",
          recommendedAction:
            "Review revenue distribution. Verify that all revenue streams are properly captured and categorized.",
          suitableForGuidedCorrection: false,
          metadata: {
            concentrationRatio: concentrationRatio.toFixed(2),
            dominantCategory: dominantCategory?.name,
            dominantAmount: dominantCategory?.amount,
            totalRevenue,
          },
        });
      }
    }

    // Check for expense concentration: if one category is >60% of total
    if (expenseRows.length > 1 && totalExpenses > 0) {
      const maxExpense = Math.max(...expenseRows.map((r) => Math.abs(r.amount)));
      const concentrationRatio = maxExpense / totalExpenses;

      if (concentrationRatio > 0.6) {
        const dominantCategory = expenseRows.find(
          (r) => Math.abs(r.amount) === maxExpense
        );
        this.findings.push({
          title: "Expense Concentration",
          severity: "medium",
          whyItMatters:
            "Expenses are heavily concentrated in one category. This may indicate miscoding, missing expense categories, or unusual business operations.",
          impactedReports: ["Profit & Loss"],
          impactedAccounts: [dominantCategory?.name || "Unknown"],
          evidenceSummary: `${(concentrationRatio * 100).toFixed(1)}% of expenses come from ${dominantCategory?.name}. Total expenses: ${totalExpenses.toFixed(2)}.`,
          confidence: "medium",
          recommendedAction:
            "Review expense distribution. Verify that expense categories are properly configured and transactions are correctly coded.",
          suitableForGuidedCorrection: false,
          metadata: {
            concentrationRatio: concentrationRatio.toFixed(2),
            dominantCategory: dominantCategory?.name,
            dominantAmount: dominantCategory?.amount,
            totalExpenses,
          },
        });
      }
    }
  }

  // ─── Step 2: Balance Sheet Analysis ───────────────────────────────────────────

  private async checkBalanceSheetStructure(bs: BalanceSheetReport): Promise<void> {
    if (!bs.rows || bs.rows.length === 0) return;

    // Parse Balance Sheet rows to extract assets, liabilities, and equity
    const assets: Array<{ name: string; amount: number }> = [];
    const liabilities: Array<{ name: string; amount: number }> = [];
    const equity: Array<{ name: string; amount: number }> = [];
    let totalAssets = 0;
    let totalLiabilities = 0;
    let totalEquity = 0;

    for (const row of bs.rows) {
      if (!row.values || row.values.length < 2) continue;

      const name = row.values[0] || "";
      const amountStr = row.values[1] || "0";
      const amount = parseFloat(amountStr.replace(/[^0-9.-]/g, "")) || 0;

      // Identify asset rows
      if (
        name.toLowerCase().includes("asset") ||
        name.toLowerCase().includes("cash") ||
        name.toLowerCase().includes("receivable") ||
        name.toLowerCase().includes("inventory") ||
        name.toLowerCase().includes("property") ||
        name.toLowerCase().includes("equipment")
      ) {
        assets.push({ name, amount });
        totalAssets += amount;
      }

      // Identify liability rows
      if (
        name.toLowerCase().includes("liability") ||
        name.toLowerCase().includes("payable") ||
        name.toLowerCase().includes("loan") ||
        name.toLowerCase().includes("debt") ||
        name.toLowerCase().includes("credit card")
      ) {
        liabilities.push({ name, amount });
        totalLiabilities += Math.abs(amount);
      }

      // Identify equity rows
      if (
        name.toLowerCase().includes("equity") ||
        name.toLowerCase().includes("capital") ||
        name.toLowerCase().includes("retained earnings") ||
        name.toLowerCase().includes("stock")
      ) {
        equity.push({ name, amount });
        totalEquity += amount;
      }
    }

    // Check 1: Abnormal asset/liability/equity balances
    await this.checkAbnormalBsBalances(assets, liabilities, equity);

    // Check 2: Suspicious account behavior
    await this.checkSuspiciousBsAccounts(assets, liabilities);

    // Check 3: Balance Sheet equation check
    await this.checkBsEquation(totalAssets, totalLiabilities, totalEquity);
  }

  /**
   * Check for abnormal balances in Balance Sheet accounts.
   * Assets should be positive, liabilities/equity should be negative or positive depending on convention.
   */
  private async checkAbnormalBsBalances(
    assets: Array<{ name: string; amount: number }>,
    liabilities: Array<{ name: string; amount: number }>,
    equity: Array<{ name: string; amount: number }>
  ): Promise<void> {
    const abnormalAccounts: Array<{ name: string; amount: number; expectedSign: string }> = [];

    // Assets should typically be positive
    for (const asset of assets) {
      if (asset.amount < 0) {
        abnormalAccounts.push({ ...asset, expectedSign: "positive" });
      }
    }

    // Liabilities should typically be negative (or positive in absolute terms)
    for (const liability of liabilities) {
      if (liability.amount > 0) {
        // Some systems show liabilities as positive, but if mixed with negative assets, it's suspicious
        if (assets.some((a) => a.amount < 0)) {
          abnormalAccounts.push({ ...liability, expectedSign: "negative or zero" });
        }
      }
    }

    // Equity should typically be positive
    for (const eq of equity) {
      if (eq.amount < 0 && !eq.name.toLowerCase().includes("retained earnings")) {
        // Retained earnings can be negative, but other equity should be positive
        abnormalAccounts.push({ ...eq, expectedSign: "positive" });
      }
    }

    if (abnormalAccounts.length > 0) {
      this.findings.push({
        title: "Abnormal Balance Sheet Balances",
        severity: "high",
        whyItMatters:
          "Balance Sheet accounts show unexpected signs or balances. This indicates data entry errors, miscoded transactions, or account configuration issues.",
        impactedReports: ["Balance Sheet"],
        impactedAccounts: abnormalAccounts.map((a) => a.name),
        evidenceSummary: `${abnormalAccounts.length} accounts have unexpected balances: ${abnormalAccounts
          .slice(0, 3)
          .map((a) => `${a.name} (${a.amount})`)
          .join(", ")}${abnormalAccounts.length > 3 ? "..." : ""}`,
        confidence: "high",
        recommendedAction:
          "Review flagged Balance Sheet accounts and correct any reversed or miscoded transactions.",
        suitableForGuidedCorrection: false,
        metadata: {
          abnormalAccountCount: abnormalAccounts.length,
          accounts: abnormalAccounts.map((a) => ({ name: a.name, amount: a.amount })),
        },
      });
    }
  }

  /**
   * Check for suspicious account behavior in Balance Sheet.
   * Detects issues with cash, receivables, payables, and undeposited funds.
   */
  private async checkSuspiciousBsAccounts(
    assets: Array<{ name: string; amount: number }>,
    liabilities: Array<{ name: string; amount: number }>
  ): Promise<void> {
    const suspiciousAccounts: Array<{ name: string; amount: number; reason: string }> = [];

    // Check for negative cash
    const cashAccounts = assets.filter(
      (a) =>
        a.name.toLowerCase().includes("cash") ||
        a.name.toLowerCase().includes("bank") ||
        a.name.toLowerCase().includes("checking")
    );
    for (const cash of cashAccounts) {
      if (cash.amount < 0) {
        suspiciousAccounts.push({
          ...cash,
          reason: "Cash account has negative balance (overdraft)",
        });
      }
    }

    // Check for negative receivables
    const arAccounts = assets.filter((a) =>
      a.name.toLowerCase().includes("receivable")
    );
    for (const ar of arAccounts) {
      if (ar.amount < 0) {
        suspiciousAccounts.push({
          ...ar,
          reason: "Accounts Receivable has negative balance (overpayments/credits)",
        });
      }
    }

    // Check for large undeposited funds
    const undeposited = assets.find(
      (a) =>
        a.name.toLowerCase().includes("undeposited") ||
        a.name.toLowerCase().includes("customer payments")
    );
    if (undeposited && undeposited.amount > 10000) {
      suspiciousAccounts.push({
        ...undeposited,
        reason: `Large undeposited funds balance (${undeposited.amount.toFixed(2)}) - should be deposited regularly`,
      });
    }

    // Check for negative payables
    const apAccounts = liabilities.filter((l) =>
      l.name.toLowerCase().includes("payable")
    );
    for (const ap of apAccounts) {
      if (ap.amount < 0) {
        suspiciousAccounts.push({
          ...ap,
          reason: "Accounts Payable has negative balance (overpayments)",
        });
      }
    }

    if (suspiciousAccounts.length > 0) {
      this.findings.push({
        title: "Suspicious Balance Sheet Account Behavior",
        severity: "high",
        whyItMatters:
          "Specific Balance Sheet accounts show behavior that indicates reconciliation issues, data entry errors, or classification problems.",
        impactedReports: ["Balance Sheet"],
        impactedAccounts: suspiciousAccounts.map((a) => a.name),
        evidenceSummary: suspiciousAccounts
          .slice(0, 3)
          .map((a) => `${a.name}: ${a.reason}`)
          .join("; "),
        confidence: "high",
        recommendedAction:
          "Investigate flagged accounts. Reconcile cash, verify receivables/payables, and deposit undeposited funds.",
        suitableForGuidedCorrection: false,
        metadata: {
          suspiciousAccountCount: suspiciousAccounts.length,
          accounts: suspiciousAccounts.map((a) => ({ name: a.name, amount: a.amount, reason: a.reason })),
        },
      });
    }
  }

  /**
   * Check Balance Sheet equation: Assets = Liabilities + Equity
   * Detects structural imbalances that indicate data integrity issues.
   */
  private async checkBsEquation(
    totalAssets: number,
    totalLiabilities: number,
    totalEquity: number
  ): Promise<void> {
    const expectedEquity = totalAssets - totalLiabilities;
    const difference = Math.abs(totalEquity - expectedEquity);
    const tolerance = Math.max(totalAssets * 0.001, 100); // 0.1% tolerance or $100

    if (difference > tolerance) {
      this.findings.push({
        title: "Balance Sheet Equation Imbalance",
        severity: "critical",
        whyItMatters:
          "The Balance Sheet does not balance (Assets ≠ Liabilities + Equity). This indicates a fundamental data integrity issue.",
        impactedReports: ["Balance Sheet"],
        impactedAccounts: ["All"],
        evidenceSummary: `Assets: ${totalAssets.toFixed(2)}, Liabilities: ${totalLiabilities.toFixed(
          2
        )}, Equity: ${totalEquity.toFixed(2)}. Difference: ${difference.toFixed(2)}`,
        confidence: "high",
        recommendedAction:
          "Investigate the Balance Sheet imbalance. Check for missing accounts, miscoded transactions, or data entry errors.",
        suitableForGuidedCorrection: false,
        metadata: {
          totalAssets,
          totalLiabilities,
          totalEquity,
          expectedEquity,
          difference,
        },
      });
    }
  }

  // ─── Step 3: GL Detail & Account Balance Analysis ──────────────────────────────

  private async checkAccountBalances(
    accounts: Account[],
    journalEntries: JournalEntry[],
    bs: BalanceSheetReport
  ): Promise<void> {
    // Check 1: Abnormal account balances
    await this.checkAbnormalBalances(accounts);

    // Check 2: A/R inconsistencies
    await this.checkArInconsistencies(accounts, journalEntries);

    // Check 3: A/P inconsistencies
    await this.checkApInconsistencies(accounts, journalEntries);

    // Check 4: Suspense account usage
    await this.checkSuspenseAccountUsage(accounts, journalEntries);
  }

  private async checkAbnormalBalances(accounts: Account[]): Promise<void> {
    const abnormalAccounts: Array<{
      name: string;
      balance: number;
      type: string;
      expectedSign: string;
    }> = [];

    for (const account of accounts) {
      // Assets should be positive
      if (account.type === "Asset" && account.currentBalance < 0) {
        abnormalAccounts.push({
          name: account.name,
          balance: account.currentBalance,
          type: account.type,
          expectedSign: "positive",
        });
      }

      // Liabilities should be negative (or positive in absolute terms)
      if (account.type === "Liability" && account.currentBalance > 0) {
        abnormalAccounts.push({
          name: account.name,
          balance: account.currentBalance,
          type: account.type,
          expectedSign: "negative",
        });
      }

      // Equity should be negative (or positive in absolute terms)
      if (account.type === "Equity" && account.currentBalance < 0) {
        abnormalAccounts.push({
          name: account.name,
          balance: account.currentBalance,
          type: account.type,
          expectedSign: "positive",
        });
      }
    }

    if (abnormalAccounts.length > 0) {
      this.findings.push({
        title: "Abnormal Account Balances",
        severity: "high",
        whyItMatters: "Account balances show unexpected signs, indicating data entry errors or miscoding.",
        impactedReports: ["Balance Sheet"],
        impactedAccounts: abnormalAccounts.map((a) => a.name),
        evidenceSummary: `${abnormalAccounts.length} accounts have unexpected balance signs.`,
        confidence: "high",
        recommendedAction: "Review and correct account balances.",
        suitableForGuidedCorrection: false,
        metadata: { abnormalAccountCount: abnormalAccounts.length },
      });
    }
  }

  private async checkArInconsistencies(
    accounts: Account[],
    journalEntries: JournalEntry[]
  ): Promise<void> {
    const arAccounts = accounts.filter((a) =>
      a.name.toLowerCase().includes("receivable")
    );

    for (const ar of arAccounts) {
      if (ar.currentBalance < 0) {
        this.findings.push({
          title: "A/R Inconsistencies",
          severity: "medium",
          whyItMatters: "Negative A/R balance indicates overpayments or credits that need investigation.",
          impactedReports: ["Balance Sheet"],
          impactedAccounts: [ar.name],
          evidenceSummary: `${ar.name} has a negative balance of ${ar.currentBalance.toFixed(2)}.`,
          confidence: "high",
          recommendedAction: "Review for overpayments, credits, or data entry errors.",
          suitableForGuidedCorrection: false,
          metadata: { arBalance: ar.currentBalance },
        });
      }
    }
  }

  private async checkApInconsistencies(
    accounts: Account[],
    journalEntries: JournalEntry[]
  ): Promise<void> {
    const apAccounts = accounts.filter((a) =>
      a.name.toLowerCase().includes("payable")
    );

    for (const ap of apAccounts) {
      if (ap.currentBalance < 0) {
        this.findings.push({
          title: "A/P Inconsistencies",
          severity: "medium",
          whyItMatters: "Negative A/P balance indicates overpayments or data entry errors.",
          impactedReports: ["Balance Sheet"],
          impactedAccounts: [ap.name],
          evidenceSummary: `${ap.name} has a negative balance of ${ap.currentBalance.toFixed(2)}.`,
          confidence: "high",
          recommendedAction: "Review for overpayments or data entry errors.",
          suitableForGuidedCorrection: false,
          metadata: { apBalance: ap.currentBalance },
        });
      }
    }
  }

  private async checkSuspenseAccountUsage(
    accounts: Account[],
    journalEntries: JournalEntry[]
  ): Promise<void> {
    const suspenseAccounts = accounts.filter(
      (a) =>
        a.name.toLowerCase().includes("suspense") ||
        a.name.toLowerCase().includes("ask my accountant")
    );

    for (const suspense of suspenseAccounts) {
      if (suspense.currentBalance !== 0) {
        this.findings.push({
          title: "Suspense / Ask My Accountant Account Usage",
          severity: "high",
          whyItMatters: "Suspense accounts should be temporary and cleared regularly.",
          impactedReports: ["Balance Sheet", "Profit & Loss"],
          impactedAccounts: [suspense.name],
          evidenceSummary: `${suspense.name} has a balance of ${suspense.currentBalance.toFixed(2)}.`,
          confidence: "high",
          recommendedAction: "Categorize all transactions in suspense accounts.",
          suitableForGuidedCorrection: false,
          metadata: { suspenseBalance: suspense.currentBalance },
        });
      }
    }
  }

  // ─── Step 4: Transaction-Level Analysis ────────────────────────────────────────

  private async checkTransactionLevelIssues(
    transactions: Transaction[],
    journalEntries: JournalEntry[],
    accounts: Account[]
  ): Promise<void> {
    // Check 1: Uncategorized transactions
    await this.checkUncategorizedTransactions(transactions);

    // Check 2: Duplicate transaction signals
    await this.checkDuplicateTransactions(transactions);

    // Check 3: Miscategorization signals
    await this.checkMiscategorization(transactions);

    // Check 4: Transfer misclassification (conservative logic)
    await this.checkTransferMisclassification(journalEntries, accounts);
  }

  private async checkUncategorizedTransactions(transactions: Transaction[]): Promise<void> {
    const uncategorized = transactions.filter(
      (t) =>
        !t.accountRef ||
        !t.accountRef.name ||
        t.accountRef.name.toLowerCase().includes("undeposited") ||
        t.accountRef.name.toLowerCase().includes("uncategorized")
    );

    if (uncategorized.length > 0) {
      this.findings.push({
        title: "Uncategorized Transactions",
        severity: "high",
        whyItMatters: "Uncategorized transactions distort financial reports and make analysis impossible.",
        impactedReports: ["Profit & Loss", "Balance Sheet"],
        impactedAccounts: ["Various"],
        evidenceSummary: `${uncategorized.length} transactions are uncategorized or in undeposited funds.`,
        confidence: "high",
        recommendedAction: "Categorize all uncategorized transactions.",
        suitableForGuidedCorrection: true,
        metadata: { uncategorizedCount: uncategorized.length },
      });
    }
  }

  private async checkDuplicateTransactions(transactions: Transaction[]): Promise<void> {
    const seen = new Map<string, Transaction[]>();

    for (const transaction of transactions) {
      const key = `${transaction.txnDate}|${transaction.amount}|${transaction.entityRef?.value || ""}`;
      if (!seen.has(key)) {
        seen.set(key, []);
      }
      seen.get(key)!.push(transaction);
    }

    const duplicateSets = Array.from(seen.values()).filter((set) => set.length > 1);

    if (duplicateSets.length > 0) {
      this.findings.push({
        title: "Duplicate Transaction Signals",
        severity: "high",
        whyItMatters: "Duplicate transactions inflate expenses and distort financial reports.",
        impactedReports: ["Profit & Loss", "Balance Sheet"],
        impactedAccounts: ["Various"],
        evidenceSummary: `${duplicateSets.length} sets of transactions with matching amounts and dates detected.`,
        confidence: "medium",
        recommendedAction: "Review and delete confirmed duplicates.",
        suitableForGuidedCorrection: false,
        metadata: { duplicateSetCount: duplicateSets.length },
      });
    }
  }

  private async checkMiscategorization(transactions: Transaction[]): Promise<void> {
    // Simple heuristic: flag transactions where description doesn't match account
    const miscategorized = transactions.filter((t) => {
      const description = (t.description || "").toLowerCase();
      const accountName = (t.accountRef?.name || "").toLowerCase();

      // If description contains common keywords but account doesn't match
      if (
        (description.includes("meal") || description.includes("restaurant")) &&
        !accountName.includes("meal") &&
        !accountName.includes("entertainment")
      ) {
        return true;
      }

      if (
        (description.includes("office") || description.includes("supplies")) &&
        !accountName.includes("office") &&
        !accountName.includes("supplies")
      ) {
        return true;
      }

      return false;
    });

    if (miscategorized.length > 0) {
      this.findings.push({
        title: "Likely Miscategorization Signals",
        severity: "medium",
        whyItMatters: "Miscategorized transactions distort expense analysis and P&L accuracy.",
        impactedReports: ["Profit & Loss"],
        impactedAccounts: ["Various"],
        evidenceSummary: `${miscategorized.length} transactions show description-to-account mismatches.`,
        confidence: "medium",
        recommendedAction: "Review and reclassify as needed.",
        suitableForGuidedCorrection: true,
        metadata: { miscategorizedCount: miscategorized.length },
      });
    }
  }

  private async checkTransferMisclassification(
    journalEntries: JournalEntry[],
    accounts: Account[]
  ): Promise<void> {
    const accountMap = new Map(accounts.map((a) => [a.id, a]));
    const likelyTransfers: Array<{ entry: JournalEntry; fromAccount: string; toAccount: string }> = [];

    for (const entry of journalEntries) {
      if (!entry.line || entry.line.length < 2) continue;

      // Look for two-line entries with matching amounts (potential transfers)
      const debits = entry.line.filter((l) => l.detailType === "Debit");
      const credits = entry.line.filter((l) => l.detailType === "Credit");

      if (debits.length === 1 && credits.length === 1) {
        const debit = debits[0];
        const credit = credits[0];

        if (debit && credit && debit.amount === credit.amount) {
          const fromAccount = accountMap.get(credit.accountRef.value);
          const toAccount = accountMap.get(debit.accountRef.value);

          // Only flag if both accounts are asset types (conservative logic)
          if (
            fromAccount &&
            toAccount &&
            fromAccount.type === "Asset" &&
            toAccount.type === "Asset"
          ) {
            likelyTransfers.push({
              entry,
              fromAccount: fromAccount.name,
              toAccount: toAccount.name,
            });
          }
        }
      }
    }

    if (likelyTransfers.length > 0) {
      this.findings.push({
        title: "Transfer Misclassification Signals",
        severity: "low",
        whyItMatters: "Transfers recorded as expenses distort P&L and expense analysis.",
        impactedReports: ["Profit & Loss"],
        impactedAccounts: likelyTransfers.map((t) => `${t.fromAccount} → ${t.toAccount}`),
        evidenceSummary: `${likelyTransfers.length} journal entries show transfer patterns between asset accounts.`,
        confidence: "low",
        recommendedAction: "Review and reclassify if confirmed transfers.",
        suitableForGuidedCorrection: false,
        metadata: { likelyTransferCount: likelyTransfers.length },
      });
    }
  }
}
