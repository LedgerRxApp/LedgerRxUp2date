/**
 * diagnostics/checks.hardened.ts
 *
 * Hardened Diagnostic Engine with QBO Type/Subtype Classification
 *
 * Improvements:
 * 1. Uses QBO account type/subtype for classification (not string matching)
 * 2. Adds materiality filtering ($100 minimum, 0.1% of total)
 * 3. Narrows transaction drilldown (only when specific anomalies found)
 * 4. Improves findings quality (financial statement impact focus)
 *
 * Maintains proper diagnostic order:
 * 1. P&L analysis
 * 2. Balance Sheet analysis
 * 3. GL detail analysis
 * 4. Transaction analysis (only if report-level anomalies found)
 */

import type { QboApiClient, ProfitAndLossReport, BalanceSheetReport, JournalEntry, Transaction, Account } from "../qbo/api";
import { AccountClassifier, isMaterial, isConcentrationMaterial, MATERIALITY } from "./accountClassifier";

// ─── Finding Type ─────────────────────────────────────────────────────────────

export interface DiagnosticFinding {
  title: string;
  severity: "critical" | "high" | "medium" | "low";
  whyItMatters: string;
  impactedReports: string[];
  impactedAccounts: string[];
  evidenceSummary: string;
  confidence: "high" | "medium" | "low";
  recommendedAction: string;
  suitableForGuidedCorrection: boolean;
  financialImpact?: {
    amount?: number;
    percentOfTotal?: number;
    reportLine?: string;
  };
  metadata?: Record<string, unknown>;
}

// ─── Drilldown Trigger ────────────────────────────────────────────────────────

/**
 * Tracks whether transaction-level checks should run.
 * Only drills into transactions when specific report-level anomalies are found.
 */
class DrilldownTrigger {
  private triggers: Set<string> = new Set();

  add(reason: string): void {
    this.triggers.add(reason);
  }

  shouldDrilldown(): boolean {
    return this.triggers.size > 0;
  }

  getActiveTriggers(): string[] {
    return Array.from(this.triggers);
  }
}

// ─── Diagnostic Pipeline ──────────────────────────────────────────────────────

export class HardenedDiagnosticEngine {
  private client: QboApiClient;
  private findings: DiagnosticFinding[] = [];
  private drilldown: DrilldownTrigger = new DrilldownTrigger();

  constructor(client: QboApiClient) {
    this.client = client;
  }

  /**
   * Runs the complete diagnostic pipeline in the correct order.
   * Uses QBO type/subtype classification and materiality filtering.
   */
  async runDiagnostics(
    startDate: string,
    endDate: string,
    asOfDate: string
  ): Promise<DiagnosticFinding[]> {
    this.findings = [];
    this.drilldown = new DrilldownTrigger();

    // Step 1: Fetch financial reports and accounts
    const pnl = await this.client.getProfitAndLoss(startDate, endDate);
    const bs = await this.client.getBalanceSheet(asOfDate);
    const accounts = await this.client.getAccounts();
    const journalEntries = await this.client.getJournalEntries(startDate, endDate);

    // Step 2: Analyze P&L structure (report-level)
    await this.checkPnlStructure(pnl, accounts);

    // Step 3: Analyze Balance Sheet structure (report-level)
    await this.checkBalanceSheetStructure(bs, accounts);

    // Step 4: Analyze GL detail and account balances
    await this.checkAccountBalances(accounts, journalEntries, bs);

    // Step 5: Analyze transactions (only if report-level anomalies found)
    if (this.drilldown.shouldDrilldown()) {
      const transactions = await this.client.getTransactions(startDate, endDate);
      await this.checkTransactionLevelIssues(transactions, journalEntries, accounts);
    }

    return this.findings;
  }

  // ─── Step 1: P&L Analysis ─────────────────────────────────────────────────────

  private async checkPnlStructure(pnl: ProfitAndLossReport, accounts: Account[]): Promise<void> {
    if (!pnl.rows || pnl.rows.length === 0) return;

    // Parse P&L rows
    const revenueRows: Array<{ name: string; amount: number }> = [];
    const expenseRows: Array<{ name: string; amount: number }> = [];
    let totalRevenue = 0;
    let totalExpenses = 0;

    for (const row of pnl.rows) {
      if (!row.values || row.values.length < 2) continue;

      const name = row.values[0] || "";
      const amountStr = row.values[1] || "0";
      const amount = parseFloat(amountStr.replace(/[^0-9.-]/g, "")) || 0;

      // Classify using account types
      const matchingAccount = accounts.find((a) => a.name === name);
      if (matchingAccount && AccountClassifier.isIncome(matchingAccount)) {
        revenueRows.push({ name, amount });
        totalRevenue += Math.abs(amount);
      } else if (matchingAccount && AccountClassifier.isExpense(matchingAccount)) {
        expenseRows.push({ name, amount });
        totalExpenses += Math.abs(amount);
      }
    }

    // Check 1: Suspicious P&L signs
    await this.checkSuspiciousPnlSigns(revenueRows, expenseRows);

    // Check 2: Revenue/expense concentration (with materiality)
    if (totalRevenue > MATERIALITY.ABSOLUTE_MINIMUM && revenueRows.length > 1) {
      await this.checkRevenueConcentration(revenueRows, totalRevenue);
    }
    if (totalExpenses > MATERIALITY.ABSOLUTE_MINIMUM && expenseRows.length > 1) {
      await this.checkExpenseConcentration(expenseRows, totalExpenses);
    }
  }

  private async checkSuspiciousPnlSigns(
    revenueRows: Array<{ name: string; amount: number }>,
    expenseRows: Array<{ name: string; amount: number }>
  ): Promise<void> {
    const suspiciousRows: Array<{ name: string; amount: number; expectedSign: string }> = [];

    // Revenue should be positive
    for (const row of revenueRows) {
      if (row.amount < 0 && isMaterial(row.amount)) {
        suspiciousRows.push({ ...row, expectedSign: "positive" });
      }
    }

    // Expenses should be negative (or positive in absolute terms)
    for (const row of expenseRows) {
      if (row.amount > 0 && revenueRows.some((r) => r.amount < 0) && isMaterial(row.amount)) {
        suspiciousRows.push({ ...row, expectedSign: "negative or zero" });
      }
    }

    if (suspiciousRows.length > 0) {
      this.findings.push({
        title: "Suspicious P&L Sign Behavior",
        severity: "high",
        whyItMatters:
          "P&L shows reversed or unexpected signs for income/expense items. This distorts profit calculations and indicates data entry errors.",
        impactedReports: ["Profit & Loss"],
        impactedAccounts: suspiciousRows.map((r) => r.name),
        evidenceSummary: `${suspiciousRows.length} line items have unexpected signs, distorting net income calculation: ${suspiciousRows
          .slice(0, 2)
          .map((r) => `${r.name} (${r.amount})`)
          .join(", ")}${suspiciousRows.length > 2 ? "..." : ""}`,
        confidence: "high",
        recommendedAction:
          "Review flagged P&L items and correct any reversed or miscoded transactions to restore accurate profit reporting.",
        suitableForGuidedCorrection: false,
        metadata: {
          suspiciousItemCount: suspiciousRows.length,
          items: suspiciousRows.map((r) => ({ name: r.name, amount: r.amount })),
        },
      });
      this.drilldown.add("pnlAnomalies");
    }
  }

  private async checkRevenueConcentration(
    revenueRows: Array<{ name: string; amount: number }>,
    totalRevenue: number
  ): Promise<void> {
    const maxRevenue = Math.max(...revenueRows.map((r) => Math.abs(r.amount)));
    const concentrationRatio = maxRevenue / totalRevenue;

    if (isConcentrationMaterial(maxRevenue, totalRevenue, 0.8)) {
      const dominantCategory = revenueRows.find((r) => Math.abs(r.amount) === maxRevenue);

      this.findings.push({
        title: "Revenue Concentration Risk",
        severity: "medium",
        whyItMatters: `${(concentrationRatio * 100).toFixed(1)}% of revenue comes from one category. This concentration distorts P&L and creates business risk if that revenue stream is disrupted.`,
        impactedReports: ["Profit & Loss"],
        impactedAccounts: [dominantCategory?.name || "Unknown"],
        evidenceSummary: `${dominantCategory?.name} accounts for ${(concentrationRatio * 100).toFixed(1)}% of total revenue (${maxRevenue.toFixed(2)} of ${totalRevenue.toFixed(2)}). This concentration distorts revenue analysis.`,
        confidence: "high",
        recommendedAction:
          "Review revenue distribution and diversification strategy. Verify all revenue streams are properly captured and categorized.",
        suitableForGuidedCorrection: false,
        financialImpact: {
          amount: maxRevenue,
          percentOfTotal: concentrationRatio,
          reportLine: "Total Income",
        },
        metadata: {
          concentrationRatio: concentrationRatio.toFixed(2),
          dominantCategory: dominantCategory?.name,
          dominantAmount: dominantCategory?.amount,
          totalRevenue,
        },
      });
      this.drilldown.add("revenueConcentration");
    }
  }

  private async checkExpenseConcentration(
    expenseRows: Array<{ name: string; amount: number }>,
    totalExpenses: number
  ): Promise<void> {
    const maxExpense = Math.max(...expenseRows.map((r) => Math.abs(r.amount)));
    const concentrationRatio = maxExpense / totalExpenses;

    if (isConcentrationMaterial(maxExpense, totalExpenses, 0.5)) {
      const dominantCategory = expenseRows.find((r) => Math.abs(r.amount) === maxExpense);

      this.findings.push({
        title: "Expense Concentration",
        severity: "medium",
        whyItMatters: `${(concentrationRatio * 100).toFixed(1)}% of expenses are in one category. This concentration distorts expense analysis and may indicate miscoding or missing expense categories.`,
        impactedReports: ["Profit & Loss"],
        impactedAccounts: [dominantCategory?.name || "Unknown"],
        evidenceSummary: `${dominantCategory?.name} accounts for ${(concentrationRatio * 100).toFixed(1)}% of total expenses (${maxExpense.toFixed(2)} of ${totalExpenses.toFixed(2)}). This distorts expense analysis and profit margins.`,
        confidence: "medium",
        recommendedAction:
          "Review expense distribution and verify that expense categories are properly configured. Confirm transactions are correctly coded.",
        suitableForGuidedCorrection: false,
        financialImpact: {
          amount: maxExpense,
          percentOfTotal: concentrationRatio,
          reportLine: "Total Expenses",
        },
        metadata: {
          concentrationRatio: concentrationRatio.toFixed(2),
          dominantCategory: dominantCategory?.name,
          dominantAmount: dominantCategory?.amount,
          totalExpenses,
        },
      });
      this.drilldown.add("expenseConcentration");
    }
  }

  // ─── Step 2: Balance Sheet Analysis ───────────────────────────────────────────

  private async checkBalanceSheetStructure(bs: BalanceSheetReport, accounts: Account[]): Promise<void> {
    if (!bs.rows || bs.rows.length === 0) return;

    // Parse Balance Sheet rows using account type classification
    const assets: Array<{ name: string; amount: number; account?: Account }> = [];
    const liabilities: Array<{ name: string; amount: number; account?: Account }> = [];
    const equity: Array<{ name: string; amount: number; account?: Account }> = [];
    let totalAssets = 0;
    let totalLiabilities = 0;
    let totalEquity = 0;

    for (const row of bs.rows) {
      if (!row.values || row.values.length < 2) continue;

      const name = row.values[0] || "";
      const amountStr = row.values[1] || "0";
      const amount = parseFloat(amountStr.replace(/[^0-9.-]/g, "")) || 0;

      const matchingAccount = accounts.find((a) => a.name === name);

      // Classify using account types (primary) + name matching (fallback)
      if (matchingAccount && AccountClassifier.isAsset(matchingAccount)) {
        assets.push({ name, amount, account: matchingAccount });
        totalAssets += amount;
      } else if (matchingAccount && AccountClassifier.isLiability(matchingAccount)) {
        liabilities.push({ name, amount, account: matchingAccount });
        totalLiabilities += Math.abs(amount);
      } else if (matchingAccount && AccountClassifier.isEquity(matchingAccount)) {
        equity.push({ name, amount, account: matchingAccount });
        totalEquity += amount;
      }
    }

    // Check 1: Abnormal balances (with materiality)
    await this.checkAbnormalBsBalances(assets, liabilities, equity);

    // Check 2: Suspicious account behavior (with materiality)
    await this.checkSuspiciousBsAccounts(assets, liabilities);

    // Check 3: Balance Sheet equation
    await this.checkBsEquation(totalAssets, totalLiabilities, totalEquity);
  }

  private async checkAbnormalBsBalances(
    assets: Array<{ name: string; amount: number; account?: Account }>,
    liabilities: Array<{ name: string; amount: number; account?: Account }>,
    equity: Array<{ name: string; amount: number; account?: Account }>
  ): Promise<void> {
    const abnormalAccounts: Array<{ name: string; amount: number; expectedSign: string }> = [];

    // Assets should typically be positive
    for (const asset of assets) {
      if (asset.amount < 0 && isMaterial(asset.amount)) {
        abnormalAccounts.push({ ...asset, expectedSign: "positive" });
      }
    }

    // Liabilities should typically be negative (or positive in absolute terms)
    for (const liability of liabilities) {
      if (liability.amount > 0 && assets.some((a) => a.amount < 0) && isMaterial(liability.amount)) {
        abnormalAccounts.push({ ...liability, expectedSign: "negative or zero" });
      }
    }

    // Equity should typically be positive
    for (const eq of equity) {
      const isRetainedEarnings = eq.account && AccountClassifier.isRetainedEarnings(eq.account);
      if (eq.amount < 0 && !isRetainedEarnings && isMaterial(eq.amount)) {
        abnormalAccounts.push({ ...eq, expectedSign: "positive" });
      }
    }

    if (abnormalAccounts.length > 0) {
      this.findings.push({
        title: "Abnormal Balance Sheet Balances",
        severity: "high",
        whyItMatters:
          "Balance Sheet accounts show unexpected signs or balances. This distorts total assets, liabilities, and equity, indicating data entry errors or miscoded transactions.",
        impactedReports: ["Balance Sheet"],
        impactedAccounts: abnormalAccounts.map((a) => a.name),
        evidenceSummary: `${abnormalAccounts.length} accounts have unexpected balances that distort Balance Sheet totals: ${abnormalAccounts
          .slice(0, 2)
          .map((a) => `${a.name} (${a.amount})`)
          .join(", ")}${abnormalAccounts.length > 2 ? "..." : ""}`,
        confidence: "high",
        recommendedAction:
          "Review flagged Balance Sheet accounts and correct any reversed or miscoded transactions to restore accurate financial position.",
        suitableForGuidedCorrection: false,
        metadata: {
          abnormalAccountCount: abnormalAccounts.length,
          accounts: abnormalAccounts.map((a) => ({ name: a.name, amount: a.amount })),
        },
      });
      this.drilldown.add("bsAnomalies");
    }
  }

  private async checkSuspiciousBsAccounts(
    assets: Array<{ name: string; amount: number; account?: Account }>,
    liabilities: Array<{ name: string; amount: number; account?: Account }>
  ): Promise<void> {
    const suspiciousAccounts: Array<{ name: string; amount: number; reason: string }> = [];

    // Check for negative cash (using account type)
    for (const asset of assets) {
      if (asset.account && AccountClassifier.isCash(asset.account)) {
        if (asset.amount < 0 && isMaterial(asset.amount)) {
          suspiciousAccounts.push({
            ...asset,
            reason: "Cash account has negative balance (overdraft) - distorts liquidity analysis",
          });
          this.drilldown.add("negativeCash");
        }
      }
    }

    // Check for negative receivables (using account type)
    for (const asset of assets) {
      if (asset.account && AccountClassifier.isAccountsReceivable(asset.account)) {
        if (asset.amount < 0 && isMaterial(asset.amount)) {
          suspiciousAccounts.push({
            ...asset,
            reason: "Accounts Receivable has negative balance (overpayments/credits) - distorts A/R analysis",
          });
          this.drilldown.add("negativeAr");
        }
      }
    }

    // Check for large undeposited funds (using account type)
    for (const asset of assets) {
      if (asset.account && AccountClassifier.isUndepositedFunds(asset.account)) {
        if (asset.amount > MATERIALITY.UNDEPOSITED_FUNDS_THRESHOLD) {
          suspiciousAccounts.push({
            ...asset,
            reason: `Large undeposited funds balance (${asset.amount.toFixed(2)}) - should be deposited regularly to avoid reconciliation issues`,
          });
          this.drilldown.add("largeUndepositedFunds");
        }
      }
    }

    // Check for suspense account usage (name-based, as QBO doesn't have specific type)
    for (const asset of assets) {
      const acct = asset.account || { id: "", name: asset.name, type: "Asset", subType: "", currentBalance: 0, active: true };
      if (AccountClassifier.isSuspense(acct)) {
        if (isMaterial(asset.amount)) {
          suspiciousAccounts.push({
            ...asset,
            reason: `Suspense account has balance (${asset.amount.toFixed(2)}) - should be cleared regularly to avoid distorting financial reports`,
          });
          this.drilldown.add("suspenseUsage");
        }
      }
    }

    if (suspiciousAccounts.length > 0) {
      this.findings.push({
        title: "Suspicious Balance Sheet Account Behavior",
        severity: "high",
        whyItMatters:
          "Specific Balance Sheet accounts show unusual behavior that distorts financial position and liquidity analysis.",
        impactedReports: ["Balance Sheet"],
        impactedAccounts: suspiciousAccounts.map((a) => a.name),
        evidenceSummary: `${suspiciousAccounts.length} accounts show suspicious behavior: ${suspiciousAccounts
          .slice(0, 2)
          .map((a) => `${a.name} - ${a.reason}`)
          .join("; ")}${suspiciousAccounts.length > 2 ? "..." : ""}`,
        confidence: "high",
        recommendedAction:
          "Review flagged accounts immediately. Correct negative cash/A/R, deposit undeposited funds, and clear suspense accounts.",
        suitableForGuidedCorrection: false,
        metadata: {
          suspiciousAccountCount: suspiciousAccounts.length,
          accounts: suspiciousAccounts.map((a) => ({ name: a.name, amount: a.amount, reason: a.reason })),
        },
      });
    }
  }

  private async checkBsEquation(totalAssets: number, totalLiabilities: number, totalEquity: number): Promise<void> {
    // Assets = Liabilities + Equity
    const difference = Math.abs(totalAssets - (totalLiabilities + totalEquity));

    if (difference > MATERIALITY.ABSOLUTE_MINIMUM) {
      this.findings.push({
        title: "Balance Sheet Equation Imbalance",
        severity: "critical",
        whyItMatters:
          "Balance Sheet does not balance (Assets ≠ Liabilities + Equity). This indicates fundamental data integrity issues.",
        impactedReports: ["Balance Sheet"],
        impactedAccounts: ["Total Assets", "Total Liabilities", "Total Equity"],
        evidenceSummary: `Assets (${totalAssets.toFixed(2)}) ≠ Liabilities (${totalLiabilities.toFixed(2)}) + Equity (${totalEquity.toFixed(2)}). Difference: ${difference.toFixed(2)}`,
        confidence: "high",
        recommendedAction:
          "Investigate and correct the imbalance immediately. This is a critical data integrity issue that must be resolved.",
        suitableForGuidedCorrection: false,
        metadata: {
          totalAssets,
          totalLiabilities,
          totalEquity,
          difference,
        },
      });
      this.drilldown.add("bsImbalance");
    }
  }

  // ─── Step 3: GL Detail Analysis ───────────────────────────────────────────────

  private async checkAccountBalances(
    accounts: Account[],
    journalEntries: JournalEntry[],
    bs: BalanceSheetReport
  ): Promise<void> {
    // Analyze account balances for anomalies
    for (const account of accounts) {
      // Skip if not material
      if (!isMaterial(account.currentBalance)) continue;

      // Check for accounts with unusual balances based on type
      if (AccountClassifier.isCash(account) && account.currentBalance < 0) {
        // Already covered in checkSuspiciousBsAccounts
        continue;
      }

      if (AccountClassifier.isAccountsReceivable(account) && account.currentBalance < 0) {
        // Already covered in checkSuspiciousBsAccounts
        continue;
      }

      // Check for accounts payable with unusual balances
      if (AccountClassifier.isAccountsPayable(account) && account.currentBalance > 0) {
        // Liabilities are typically shown as negative
        this.findings.push({
          title: "Unusual Accounts Payable Balance",
          severity: "medium",
          whyItMatters: "Accounts Payable shows unexpected balance sign. This may indicate data entry errors or account configuration issues.",
          impactedReports: ["Balance Sheet"],
          impactedAccounts: [account.name],
          evidenceSummary: `${account.name} has balance of ${account.currentBalance.toFixed(2)}. Accounts Payable should typically be negative.`,
          confidence: "medium",
          recommendedAction: "Review account configuration and verify balance sign is correct.",
          suitableForGuidedCorrection: false,
        });
        this.drilldown.add("apAnomalies");
      }
    }
  }

  // ─── Step 4: Transaction Analysis (only if drilldown triggered) ────────────────

  private async checkTransactionLevelIssues(
    transactions: Transaction[],
    journalEntries: JournalEntry[],
    accounts: Account[]
  ): Promise<void> {
    // Only run if specific report-level anomalies were found
    if (!this.drilldown.shouldDrilldown()) return;

    // Check 1: Uncategorized transactions
    const uncategorizedTxns = transactions.filter((t) => {
      if (!t.accountRef) return true;
      const accountName = typeof t.accountRef === 'object' ? t.accountRef?.name : t.accountRef;
      return !accountName || (typeof accountName === 'string' && accountName.trim() === "");
    });
    if (uncategorizedTxns.length > 0) {
      const totalAmount = uncategorizedTxns.reduce((sum, t) => sum + Math.abs(t.amount || 0), 0);
      if (isMaterial(totalAmount)) {
        this.findings.push({
          title: "Uncategorized Transactions",
          severity: "high",
          whyItMatters: `${uncategorizedTxns.length} transactions are uncategorized, distorting P&L and Balance Sheet totals by ${totalAmount.toFixed(2)}.`,
          impactedReports: ["Profit & Loss", "Balance Sheet"],
          impactedAccounts: ["Uncategorized"],
          evidenceSummary: `${uncategorizedTxns.length} transactions totaling ${totalAmount.toFixed(2)} lack account assignments. These distort financial reports.`,
          confidence: "high",
          recommendedAction:
            "Categorize all uncategorized transactions to restore accurate financial reporting.",
          suitableForGuidedCorrection: true,
          metadata: {
            count: uncategorizedTxns.length,
            totalAmount,
          },
        });
      }
    }

    // Check 2: Duplicate transaction signals
    const duplicates = this.detectDuplicateTransactions(transactions);
    if (duplicates.length > 0) {
      const totalAmount = duplicates.reduce((sum, d) => sum + Math.abs(d.amount || 0), 0);
      if (isMaterial(totalAmount)) {
          this.findings.push({
        title: "Duplicate Transaction Signals",
        severity: "high",
        whyItMatters: `${duplicates.length} potential duplicate transactions detected, inflating expenses by ${totalAmount.toFixed(2)}.`,
        impactedReports: ["Profit & Loss"],
        impactedAccounts: duplicates.map((d) => typeof d.accountRef === 'object' ? d.accountRef?.name || "Unknown" : d.accountRef || "Unknown").slice(0, 3),
          evidenceSummary: `${duplicates.length} transactions with matching amounts, dates, and entities suggest duplicates totaling ${totalAmount.toFixed(2)}.`,
          confidence: "medium",
          recommendedAction:
            "Review flagged transactions and delete confirmed duplicates to restore accurate expense reporting.",
          suitableForGuidedCorrection: true,
          metadata: {
            count: duplicates.length,
            totalAmount,
          },
        });
      }
    }

    // Check 3: Miscategorization signals
    const miscategorized = this.detectMiscategorization(transactions);
    if (miscategorized.length > 0) {
      const totalAmount = miscategorized.reduce((sum, m) => sum + Math.abs(m.amount || 0), 0);
      if (isMaterial(totalAmount)) {
          this.findings.push({
        title: "Likely Miscategorization Signals",
        severity: "medium",
        whyItMatters: `${miscategorized.length} transactions show description-to-account mismatches, distorting expense analysis by ${totalAmount.toFixed(2)}.`,
        impactedReports: ["Profit & Loss"],
        impactedAccounts: miscategorized.map((m) => typeof m.accountRef === 'object' ? m.accountRef?.name || "Unknown" : m.accountRef || "Unknown").slice(0, 3),
          evidenceSummary: `${miscategorized.length} transactions with description-account mismatches (e.g., "Rent" in Supplies account) totaling ${totalAmount.toFixed(2)}.`,
          confidence: "medium",
          recommendedAction:
            "Review flagged transactions and recategorize to correct accounts to restore accurate expense analysis.",
          suitableForGuidedCorrection: true,
          metadata: {
            count: miscategorized.length,
            totalAmount,
          },
        });
      }
    }

    // Check 4: Transfer misclassification (conservative logic)
    const transfers = this.detectTransferMisclassification(transactions, accounts);
    if (transfers.length > 0) {
      const totalAmount = transfers.reduce((sum, t) => sum + Math.abs(t.amount || 0), 0);
      if (isMaterial(totalAmount)) {
        this.findings.push({
          title: "Likely Transfer Misclassification",
          severity: "medium",
          whyItMatters: `${transfers.length} transactions appear to be transfers but are coded as expenses, distorting P&L by ${totalAmount.toFixed(2)}.`,
          impactedReports: ["Profit & Loss"],
          impactedAccounts: transfers.map((t) => typeof t.accountRef === 'object' ? t.accountRef?.name || "Unknown" : t.accountRef || "Unknown").slice(0, 3),
          evidenceSummary: `${transfers.length} transactions with matching amounts between bank and liability accounts suggest transfers miscoded as expenses.`,
          confidence: "low",
          recommendedAction:
            "Review flagged transactions. If confirmed as transfers, reclassify to balance sheet accounts.",
          suitableForGuidedCorrection: false,
          metadata: {
            count: transfers.length,
            totalAmount,
          },
        });
      }
    }
  }

  private detectDuplicateTransactions(transactions: Transaction[]): Transaction[] {
    const duplicates: Transaction[] = [];
    const seen = new Map<string, Transaction>();

    for (const txn of transactions) {
      const entityName = typeof txn.entityRef === 'object' ? txn.entityRef?.name : txn.entityRef;
      const key = `${txn.amount}|${txn.txnDate}|${entityName || ""}`;
      if (seen.has(key)) {
        duplicates.push(txn);
      } else {
        seen.set(key, txn);
      }
    }

    return duplicates;
  }

  private detectMiscategorization(transactions: Transaction[]): Transaction[] {
    const miscategorized: Transaction[] = [];
    const suspiciousKeywords = ["rent", "utilities", "insurance", "payroll", "office"];

    for (const txn of transactions) {
      const description = txn.description?.toLowerCase() || "";
      const accountName = typeof txn.accountRef === 'object' ? (txn.accountRef?.name || "").toLowerCase() : (txn.accountRef || "").toLowerCase();

      for (const keyword of suspiciousKeywords) {
        if (description.includes(keyword) && accountName && !accountName.includes(keyword)) {
          miscategorized.push(txn);
          break;
        }
      }
    }

    return miscategorized;
  }

  private detectTransferMisclassification(transactions: Transaction[], accounts: Account[]): Transaction[] {
    const transfers: Transaction[] = [];

    for (const txn of transactions) {
      // Conservative logic: only flag if amount matches another transaction exactly
      // and accounts are compatible types (bank to bank, or bank to liability)
      const matchingTxns = transactions.filter((t) => Math.abs((t.amount || 0) - (txn.amount || 0)) < 0.01 && t.id !== txn.id);

      if (matchingTxns.length > 0) {
        const txnAccountName = typeof txn.accountRef === 'object' ? txn.accountRef?.name : txn.accountRef;
        const matchAccountName = typeof matchingTxns[0]?.accountRef === 'object' ? matchingTxns[0]?.accountRef?.name : matchingTxns[0]?.accountRef;
        
        const txnAccount = accounts.find((a) => a.name === txnAccountName);
        const matchAccount = accounts.find((a) => a.name === matchAccountName);

        // Only flag if both accounts are balance sheet accounts (compatible for transfers)
        if (
          txnAccount &&
          matchAccount &&
          AccountClassifier.isBalanceSheetAccount(txnAccount) &&
          AccountClassifier.isBalanceSheetAccount(matchAccount)
        ) {
          transfers.push(txn);
        }
      }
    }

    return transfers;
  }
}
