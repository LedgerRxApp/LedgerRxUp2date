/**
 * diagnostics/runs.ts
 *
 * Database helpers for healthcheck_runs table.
 */

import { eq, and, desc } from "drizzle-orm";
import { getDb } from "../../db";
import {
  healthcheckRuns,
  type HealthcheckRun,
  type InsertHealthcheckRun,
} from "../../../drizzle/schema";

export async function createRun(
  data: InsertHealthcheckRun
): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(healthcheckRuns).values(data);
  return (result as unknown as { insertId: number }).insertId;
}

export async function getRunsByUser(userId: number): Promise<HealthcheckRun[]> {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(healthcheckRuns)
    .where(eq(healthcheckRuns.userId, userId))
    .orderBy(desc(healthcheckRuns.startedAt));
}

export async function getRunById(
  id: number,
  userId: number
): Promise<HealthcheckRun | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const rows = await db
    .select()
    .from(healthcheckRuns)
    .where(and(eq(healthcheckRuns.id, id), eq(healthcheckRuns.userId, userId)))
    .limit(1);

  return rows[0];
}

export async function updateRunStatus(
  id: number,
  update: Partial<Pick<HealthcheckRun, "status" | "totalChecks" | "totalFindings" | "durationMs" | "completedAt" | "errorMessage">>
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(healthcheckRuns)
    .set(update)
    .where(eq(healthcheckRuns.id, id));
}
