/**
 * copilot module  [SCAFFOLD — Phase 3]
 *
 * The Cleanup Copilot generates AI-powered suggestions for resolving findings.
 * Each suggestion is linked to a finding and describes a concrete action the
 * user (or the system, for auto_fix actions) can take to clean up the data.
 *
 * Phase 3 implementation plan:
 *   1. For each open finding, call invokeLLM() with the finding context
 *   2. Parse the structured response into a CopilotSuggestion record
 *   3. Store suggestions via insertSuggestions()
 *   4. For auto_fix suggestions, build a QBO API write payload
 *   5. Expose an "Apply Fix" action that executes the payload via the QBO API
 */

import { eq, and } from "drizzle-orm";
import { getDb } from "../../db";
import {
  copilotSuggestions,
  type CopilotSuggestion,
  type InsertCopilotSuggestion,
} from "../../../drizzle/schema";

// ─── Query helpers ────────────────────────────────────────────────────────────

/**
 * Returns all copilot suggestions for a given finding.
 */
export async function getSuggestionsByFinding(
  findingId: number
): Promise<CopilotSuggestion[]> {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(copilotSuggestions)
    .where(eq(copilotSuggestions.findingId, findingId));
}

/**
 * Returns all copilot suggestions for a user.
 */
export async function getSuggestionsByUser(
  userId: number
): Promise<CopilotSuggestion[]> {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(copilotSuggestions)
    .where(eq(copilotSuggestions.userId, userId));
}

/**
 * Inserts a batch of copilot suggestions.
 */
export async function insertSuggestions(
  items: InsertCopilotSuggestion[]
): Promise<void> {
  if (items.length === 0) return;
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(copilotSuggestions).values(items);
}

/**
 * Updates the status of a suggestion (accept, reject, or mark applied).
 */
export async function updateSuggestionStatus(
  id: number,
  userId: number,
  status: "accepted" | "rejected" | "applied"
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(copilotSuggestions)
    .set({
      status,
      appliedAt: status === "applied" ? new Date() : undefined,
    })
    .where(
      and(
        eq(copilotSuggestions.id, id),
        eq(copilotSuggestions.userId, userId)
      )
    );
}

/**
 * Generates copilot suggestions for a finding.
 * [SCAFFOLD] — LLM integration wired in Phase 3.
 */
export async function generateSuggestionsForFinding(
  _findingId: number,
  _userId: number
): Promise<void> {
  // Phase 3: call invokeLLM() with finding context, parse structured response,
  // and call insertSuggestions() with the result.
  throw new Error(
    "Copilot suggestion generation is not yet implemented (Phase 3)."
  );
}
