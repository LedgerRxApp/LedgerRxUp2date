/**
 * findings/generator.ts
 *
 * Converts diagnostic findings to database records with proper evidence linking
 * and severity grouping.
 *
 * Each finding includes:
 * - Structured metadata with evidence references
 * - Severity level for UI prioritization
 * - Recommended actions
 * - Suitability for guided correction vs. manual review
 */

import { getDb } from "../../db";
import { findings as findingsTable, type InsertFinding } from "../../../drizzle/schema";
import type { DiagnosticFinding } from "../diagnostics/checks";

// ─── Finding Generator ─────────────────────────────────────────────────────────

export class FindingsGenerator {
  /**
   * Converts diagnostic findings to database records and persists them.
   * Groups findings by severity for easy filtering.
   */
  async generateAndPersistFindings(
    healthcheckRunId: number,
    userId: number,
    diagnosticFindings: DiagnosticFinding[]
  ): Promise<{
    totalFindings: number;
    bySeverity: Record<string, number>;
    findingIds: number[];
  }> {
    const db = await getDb();
    if (!db) {
      throw new Error("Database not available");
    }

    const findingIds: number[] = [];
    const bySeverity: Record<string, number> = {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0,
    };

    for (const finding of diagnosticFindings) {
      const insertRecord: InsertFinding = {
        healthcheckRunId,
        userId,
        checkKey: this.generateCheckKey(finding.title),
        title: finding.title,
        description: this.buildDescription(finding),
        severity: this.mapSeverity(finding.severity),
        status: "open",
        metadata: {
          whyItMatters: finding.whyItMatters,
          impactedReports: finding.impactedReports,
          impactedAccounts: finding.impactedAccounts,
          evidenceSummary: finding.evidenceSummary,
          confidence: finding.confidence,
          recommendedAction: finding.recommendedAction,
          suitableForGuidedCorrection: finding.suitableForGuidedCorrection,
          ...finding.metadata,
        },
        affectedCount: this.extractAffectedCount(finding),
      };

      const result = await db.insert(findingsTable).values(insertRecord);

      // Get the inserted ID from the result
      if (result && typeof result === 'object' && 'insertId' in result) {
        findingIds.push((result as any).insertId as number);
      }

      bySeverity[this.mapSeverity(finding.severity)]++;
    }

    return {
      totalFindings: diagnosticFindings.length,
      bySeverity: bySeverity,
      findingIds,
    };
  }

  /**
   * Generates a machine-readable check key from the finding title.
   * Used for grouping and filtering findings.
   */
  private generateCheckKey(title: string): string {
    return title
      .toLowerCase()
      .replace(/\s+/g, "_")
      .replace(/[^a-z0-9_]/g, "")
      .substring(0, 128);
  }

  /**
   * Builds a human-readable description from the finding.
   * Includes evidence, impact, and recommended action.
   */
  private buildDescription(finding: DiagnosticFinding): string {
    return `
${finding.whyItMatters}

**Evidence:** ${finding.evidenceSummary}

**Impacted Reports:** ${finding.impactedReports.join(", ")}
**Impacted Accounts:** ${finding.impactedAccounts.join(", ")}

**Confidence:** ${finding.confidence}
**Recommended Action:** ${finding.recommendedAction}
**Suitable for Guided Correction:** ${finding.suitableForGuidedCorrection ? "Yes" : "No"}
    `.trim();
  }

  /**
   * Maps diagnostic severity to database enum.
   */
  private mapSeverity(
    severity: "critical" | "high" | "medium" | "low"
  ): "critical" | "warning" | "info" {
    if (severity === "critical") return "critical";
    if (severity === "high") return "warning";
    return "info";
  }

  /**
   * Extracts the affected count from finding metadata.
   */
  private extractAffectedCount(finding: DiagnosticFinding): number {
    if (!finding.metadata) return 0;

    // Look for common count fields
    const countFields = [
      "abnormalAccountCount",
      "uncategorizedCount",
      "duplicateSetCount",
      "miscategorizedCount",
      "likelyTransferCount",
      "negativeArCount",
      "positiveApCount",
      "suspenseAccountCount",
    ];

    for (const field of countFields) {
      const value = (finding.metadata as Record<string, unknown>)[field];
      if (typeof value === "number") {
        return value;
      }
    }

    return 0;
  }
}

/**
 * Groups findings by severity for UI display.
 */
export function groupFindingsBySeverity(
  findings: DiagnosticFinding[]
): Record<string, DiagnosticFinding[]> {
  const grouped: Record<string, DiagnosticFinding[]> = {
    critical: [],
    high: [],
    medium: [],
    low: [],
  };

  for (const finding of findings) {
    grouped[finding.severity].push(finding);
  }

  return grouped;
}

/**
 * Filters findings by severity level.
 */
export function filterFindingsBySeverity(
  findings: DiagnosticFinding[],
  minSeverity: "critical" | "high" | "medium" | "low"
): DiagnosticFinding[] {
  const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
  const minLevel = severityOrder[minSeverity];

  return findings.filter((f) => severityOrder[f.severity] <= minLevel);
}

/**
 * Generates a summary report of findings.
 */
export function generateFindingsSummary(findings: DiagnosticFinding[]): {
  total: number;
  bySeverity: Record<string, number>;
  topIssues: string[];
  recommendedActions: string[];
} {
  const grouped = groupFindingsBySeverity(findings);
  const bySeverity: Record<string, number> = {
    critical: grouped.critical.length,
    high: grouped.high.length,
    medium: grouped.medium.length,
    low: grouped.low.length,
  };

  const topIssues = [
    ...grouped.critical,
    ...grouped.high,
    ...grouped.medium,
  ]
    .slice(0, 5)
    .map((f) => f.title);

  const recommendedActionsSet = new Set(
    findings
      .filter((f) => f.severity === "critical" || f.severity === "high")
      .map((f) => f.recommendedAction)
  );
  const recommendedActions = Array.from(recommendedActionsSet);

  return {
    total: findings.length,
    bySeverity,
    topIssues,
    recommendedActions,
  };
}
