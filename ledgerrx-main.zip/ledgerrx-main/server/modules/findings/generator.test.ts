/**
 * findings/generator.test.ts
 *
 * Vitest tests for findings generator.
 * Verifies that findings are correctly persisted to the database
 * and summarized with proper severity grouping.
 */

import { describe, it, expect } from "vitest";
import { FindingsGenerator, groupFindingsBySeverity, generateFindingsSummary } from "./generator";
import type { DiagnosticFinding } from "../diagnostics/checks";

// ─── Mock Findings ────────────────────────────────────────────────────────────

const mockFindings: DiagnosticFinding[] = [
  {
    title: "Abnormal Account Balances",
    severity: "high",
    whyItMatters: "Asset accounts should not have negative balances.",
    impactedReports: ["Balance Sheet"],
    impactedAccounts: ["Cash", "Bank Account"],
    evidenceSummary: "2 accounts have unexpected balance signs.",
    confidence: "high",
    recommendedAction: "Review account balances.",
    suitableForGuidedCorrection: false,
    metadata: {
      abnormalAccountCount: 2,
    },
  },
  {
    title: "Duplicate Transaction Signals",
    severity: "high",
    whyItMatters: "Duplicate transactions inflate expenses.",
    impactedReports: ["Profit & Loss"],
    impactedAccounts: ["Sales"],
    evidenceSummary: "3 sets of transactions with matching amounts detected.",
    confidence: "medium",
    recommendedAction: "Review and delete confirmed duplicates.",
    suitableForGuidedCorrection: false,
    metadata: {
      duplicateSetCount: 3,
    },
  },
  {
    title: "Suspense Account Usage",
    severity: "critical",
    whyItMatters: "Suspense accounts should be temporary.",
    impactedReports: ["Profit & Loss", "Balance Sheet"],
    impactedAccounts: ["Suspense"],
    evidenceSummary: "1 suspense account has a balance of $2,500.",
    confidence: "high",
    recommendedAction: "Categorize all transactions in suspense.",
    suitableForGuidedCorrection: false,
    metadata: {
      suspenseAccountCount: 1,
      totalBalance: 2500,
    },
  },
  {
    title: "Likely Miscategorization Signals",
    severity: "medium",
    whyItMatters: "Miscategorized transactions distort expense analysis.",
    impactedReports: ["Profit & Loss"],
    impactedAccounts: ["Office Supplies", "Meals & Entertainment"],
    evidenceSummary: "5 transactions show description-to-account mismatches.",
    confidence: "medium",
    recommendedAction: "Review and reclassify as needed.",
    suitableForGuidedCorrection: true,
    metadata: {
      miscategorizedCount: 5,
    },
  },
  {
    title: "A/R Inconsistencies",
    severity: "medium",
    whyItMatters: "Negative A/R indicates overpayments.",
    impactedReports: ["Balance Sheet"],
    impactedAccounts: ["Accounts Receivable"],
    evidenceSummary: "1 A/R account has a negative balance.",
    confidence: "high",
    recommendedAction: "Review for overpayments or credits.",
    suitableForGuidedCorrection: false,
    metadata: {
      negativeArCount: 1,
    },
  },
  {
    title: "Transfer Misclassification Signals",
    severity: "low",
    whyItMatters: "Transfers recorded as expenses distort P&L.",
    impactedReports: ["Profit & Loss"],
    impactedAccounts: ["Bank Account", "Savings Account"],
    evidenceSummary: "2 journal entries show transfer patterns.",
    confidence: "low",
    recommendedAction: "Review and reclassify if confirmed transfers.",
    suitableForGuidedCorrection: false,
    metadata: {
      likelyTransferCount: 2,
    },
  },
];

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("FindingsGenerator", () => {
  describe("groupFindingsBySeverity", () => {
    it("should group findings by severity level", () => {
      const grouped = groupFindingsBySeverity(mockFindings);

      expect(grouped.critical).toHaveLength(1);
      expect(grouped.high).toHaveLength(2);
      expect(grouped.medium).toHaveLength(2);
      expect(grouped.low).toHaveLength(1);
    });

    it("should correctly identify critical findings", () => {
      const grouped = groupFindingsBySeverity(mockFindings);

      expect(grouped.critical[0]?.title).toBe("Suspense Account Usage");
    });

    it("should handle empty findings array", () => {
      const grouped = groupFindingsBySeverity([]);

      expect(grouped.critical).toHaveLength(0);
      expect(grouped.high).toHaveLength(0);
      expect(grouped.medium).toHaveLength(0);
      expect(grouped.low).toHaveLength(0);
    });
  });

  describe("generateFindingsSummary", () => {
    it("should generate correct severity counts", () => {
      const summary = generateFindingsSummary(mockFindings);

      expect(summary.total).toBe(6);
      expect(summary.bySeverity.critical).toBe(1);
      expect(summary.bySeverity.high).toBe(2);
      expect(summary.bySeverity.medium).toBe(2);
      expect(summary.bySeverity.low).toBe(1);
    });

    it("should include top 5 issues", () => {
      const summary = generateFindingsSummary(mockFindings);

      expect(summary.topIssues).toHaveLength(5);
      expect(summary.topIssues).toContain("Suspense Account Usage");
      expect(summary.topIssues).toContain("Abnormal Account Balances");
    });

    it("should include recommended actions for critical and high findings", () => {
      const summary = generateFindingsSummary(mockFindings);

      expect(summary.recommendedActions.length).toBeGreaterThan(0);
      expect(summary.recommendedActions).toContain("Categorize all transactions in suspense.");
    });

    it("should handle empty findings", () => {
      const summary = generateFindingsSummary([]);

      expect(summary.total).toBe(0);
      expect(summary.topIssues).toHaveLength(0);
      expect(summary.recommendedActions).toHaveLength(0);
    });
  });

  describe("FindingsGenerator.generateCheckKey", () => {
    it("should generate machine-readable check keys", () => {
      const generator = new FindingsGenerator();

      // Access private method via any for testing
      const key = (generator as any).generateCheckKey("Abnormal Account Balances");

      expect(key).toBe("abnormal_account_balances");
      expect(key).toMatch(/^[a-z0-9_]+$/);
    });

    it("should handle special characters", () => {
      const generator = new FindingsGenerator();
      const key = (generator as any).generateCheckKey("A/R Inconsistencies (Test)");

      expect(key).toMatch(/^[a-z0-9_]+$/);
      expect(key.length).toBeLessThanOrEqual(128);
    });
  });

  describe("FindingsGenerator.mapSeverity", () => {
    it("should map diagnostic severity to database enum", () => {
      const generator = new FindingsGenerator();

      expect((generator as any).mapSeverity("critical")).toBe("critical");
      expect((generator as any).mapSeverity("high")).toBe("warning");
      expect((generator as any).mapSeverity("medium")).toBe("info");
      expect((generator as any).mapSeverity("low")).toBe("info");
    });
  });

  describe("FindingsGenerator.extractAffectedCount", () => {
    it("should extract affected count from metadata", () => {
      const generator = new FindingsGenerator();

      const finding: DiagnosticFinding = {
        title: "Test",
        severity: "high",
        whyItMatters: "Test",
        impactedReports: [],
        impactedAccounts: [],
        evidenceSummary: "Test",
        confidence: "high",
        recommendedAction: "Test",
        suitableForGuidedCorrection: false,
        metadata: {
          abnormalAccountCount: 5,
        },
      };

      const count = (generator as any).extractAffectedCount(finding);
      expect(count).toBe(5);
    });

    it("should return 0 if no count field found", () => {
      const generator = new FindingsGenerator();

      const finding: DiagnosticFinding = {
        title: "Test",
        severity: "high",
        whyItMatters: "Test",
        impactedReports: [],
        impactedAccounts: [],
        evidenceSummary: "Test",
        confidence: "high",
        recommendedAction: "Test",
        suitableForGuidedCorrection: false,
        metadata: {
          someOtherField: "value",
        },
      };

      const count = (generator as any).extractAffectedCount(finding);
      expect(count).toBe(0);
    });
  });
});
