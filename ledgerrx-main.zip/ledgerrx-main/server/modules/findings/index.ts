/**
 * findings module
 *
 * Database query helpers for the findings table.
 * Findings are created by diagnostic checks and surfaced in the dashboard.
 */

import { eq, and, desc } from "drizzle-orm";
import { getDb } from "../../db";
import {
  findings,
  type Finding,
  type InsertFinding,
} from "../../../drizzle/schema";

// ─── Query helpers ────────────────────────────────────────────────────────────

/**
 * Returns all findings for a user, ordered newest-first.
 */
export async function getFindingsByUser(userId: number): Promise<Finding[]> {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(findings)
    .where(eq(findings.userId, userId))
    .orderBy(desc(findings.createdAt));
}

/**
 * Returns all findings for a specific healthcheck run.
 */
export async function getFindingsByRun(
  healthcheckRunId: number
): Promise<Finding[]> {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(findings)
    .where(eq(findings.healthcheckRunId, healthcheckRunId))
    .orderBy(desc(findings.createdAt));
}

/**
 * Returns a single finding by ID, scoped to the requesting user.
 */
export async function getFindingById(
  id: number,
  userId: number
): Promise<Finding | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const rows = await db
    .select()
    .from(findings)
    .where(and(eq(findings.id, id), eq(findings.userId, userId)))
    .limit(1);

  return rows[0];
}

/**
 * Inserts a batch of findings produced by a diagnostic run.
 */
export async function insertFindings(
  items: InsertFinding[]
): Promise<void> {
  if (items.length === 0) return;
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(findings).values(items);
}

/**
 * Updates the status of a finding (resolve or dismiss).
 */
export async function updateFindingStatus(
  id: number,
  userId: number,
  status: "resolved" | "dismissed"
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(findings)
    .set({
      status,
      resolvedAt: status === "resolved" ? new Date() : undefined,
    })
    .where(and(eq(findings.id, id), eq(findings.userId, userId)));
}
