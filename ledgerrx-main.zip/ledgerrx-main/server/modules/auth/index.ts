/**
 * auth module
 *
 * Thin helpers that sit on top of the platform's built-in session/cookie
 * infrastructure.  The heavy lifting (JWT signing, cookie options, OAuth
 * callback) is handled by server/_core.  This module exposes convenience
 * utilities that the rest of the application can import without touching
 * _core internals.
 */

import type { User } from "../../../drizzle/schema";

// ─── Types ────────────────────────────────────────────────────────────────────

export type SessionUser = Pick<
  User,
  "id" | "openId" | "name" | "email" | "role"
>;

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Returns true when the supplied user has the "admin" role.
 */
export function isAdmin(user: SessionUser | null | undefined): boolean {
  return user?.role === "admin";
}

/**
 * Returns a display-safe name for the user, falling back gracefully.
 */
export function displayName(user: SessionUser | null | undefined): string {
  if (!user) return "Guest";
  return user.name ?? user.email ?? user.openId;
}
